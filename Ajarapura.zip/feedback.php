

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from www.jepurpanchayat.com/feedback.aspx by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 04 May 2018 10:45:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <!-- Meta -->
    <meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" /><meta name="description" /><meta name="author" /><meta name="keywords" content="Jepur Gram Panchayat Vijapur, Gram Panchayat Jepur, Online Jepur Panchayat, Jepur Vijapur, Gram Panchayat Vijapur, Gram Panchayat Software, Jepur Vijapur Mehsana, Gujarat" /><meta name="robots" content="all" /><title>
	અજરાપુરા ગ્રામ પંચાયત
</title>

    <!-- Style Sheet : START -->
    

<!-- Bootstrap Core CSS -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
<!-- Customizable CSS -->
<link rel="stylesheet" href="assets/css/main.css" />
<link rel="stylesheet" href="assets/css/blue.css" />
<link rel="stylesheet" href="assets/css/owl.carousel.css" />
<link rel="stylesheet" href="assets/css/owl.transitions.css" />
<link rel="stylesheet" href="assets/css/animate.min.css" />
<link rel="stylesheet" href="assets/css/rateit.css" />
<link rel="stylesheet" href="assets/css/bootstrap-select.min.css" />
<link href="assets/css/lightbox.css" rel="stylesheet">

<!-- Icons/Glyphs -->
<link rel="stylesheet" href="assets/css/font-awesome.css" />

<!-- Fonts -->
<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css' />
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,600italic,700,700italic,800' rel='stylesheet' type='text/css' />
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />



    <!-- Style Sheet : START -->
</head>
<body>
    <form method="post" action="mailto: mayur74patel@gmail.com" id="form1" class="register-form">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUJNjUwNjY0MjM3D2QWAgIDD2QWAgIDD2QWAmYPZBYEAgEPZBYCAhUPFgIeBWNsYXNzBQZhY3RpdmVkAhEPZBYEAgEPFgIeC18hSXRlbUNvdW50AgEWAmYPZBYCZg8VA7cB4Kq14Kqw4KuN4Kq3IDog4Kuo4Kum4Kun4KuuLeCrp+CrryDgqq7gqr7gqp/gq4cg4KqW4KuH4Kqk4KuA4Kq14Kq+4Kqh4KuA4Kqo4KuAIOCqteCqv+CqteCqv+CqpyDgqq/gq4vgqpzgqqjgqr7gqpPgqqjgq4Ag4KqT4Kqo4Kqy4Kq+4KqH4KqoIOCqheCqsOCqnOCrgOCqkyDgqq7gqr7gqp/gq4cgQ2xpY2sg4KqV4Kqw4KuLLWh0dHA6Ly93d3cuamVwdXJwYW5jaGF5YXQuY29tL2dvdnByb2plY3QuYXNweLcB4Kq14Kqw4KuN4Kq3IDog4Kuo4Kum4Kun4KuuLeCrp+CrryDgqq7gqr7gqp/gq4cg4KqW4KuH4Kqk4KuA4Kq14Kq+4Kqh4KuA4Kqo4KuAIOCqteCqv+CqteCqv+CqpyDgqq/gq4vgqpzgqqjgqr7gqpPgqqjgq4Ag4KqT4Kqo4Kqy4Kq+4KqH4KqoIOCqheCqsOCqnOCrgOCqkyDgqq7gqr7gqp/gq4cgQ2xpY2sg4KqV4Kqw4KuLZAIDDxYCHwECARYCZg9kFgJmDxUDe+Cql+CqvuCqruCqqOCriyDgqrXgqr/gqpXgqr7gqrgg4KqF4Kqo4KuHIOCql+CqvuCqriDgqq7gqr7gqoIg4Kqf4KuH4KqV4Kqo4KuL4Kqy4KuL4Kqc4KuAIOCqj+CqleCqpuCqriDgqoXgqqfgqqTgqqgg4Kqb4KuHLgZUQVJFU0gHTUVIU0FOQWRk54WkBeKPUoy4LlXrWveYwlWPeMNGFmqdHSW8Z4Mikkk=" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="WebResource1b08.js?d=UrOvl_HgGqXWtmxd--EEumKt1q8cUGxIRA-dyGXsSqsd_DQJfiy7NWTVGbJbdc8wN9KugmUD_wPR1-lu6o0Qhh5M7ED--d7A8M_e-o9OlAg1&amp;t=636596762276020154" type="text/javascript"></script>


<script src="ScriptResource02e0.js?d=VMm4ppQAyeXb9teYSyrNpt6gYgIjcoU0Y0E7qjVmDGKxJOh0EK4em33vVED_eJr98J5RDedK4M8d_boNZJAYElxxi2B_T_Xhb839463HY-aGp-gg4kWV8V-kQHrsqdUDssjPNQumNQQGVj4tzotH8yBSkH-wVYsOmab4JrJNQiFsQHpAwKTXCP3QILYe6u8K0&amp;t=ffffffffcc58dd65" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
if (typeof(Sys) === 'undefined') throw new Error('ASP.NET Ajax client-side framework failed to load.');
//]]>
</script>

<script src="ScriptResourcef496.js?d=6cyO38t2NOWdod39ZvW0zit3wuc7Z0h9_x4lNktubvmryvHCMD-8-7JXN4iK18Sril5yOTa4P65EyhwnD7boXm-AlNUelwXzEK0anz9cTjFCdaMuWK0B1mm2sphLknzQ9sWEOprVK_SvWCZshCz4sL7v6sQi10o5MnNp9pV-J07_AlB94Hm4-4C87kScdN6j0&amp;t=ffffffffcc58dd65" type="text/javascript"></script>
<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="96C56D28" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAAa69Jx7SmaU/nt8p3beuvaZozoJZpuXxkpOVJKRbHyuHhXE3dkwa1cRACVa3MHp4BsrmtCHLRrNXCrKIKqPA4/YEVY5u54TgWwyd97xcy3QijzmltaUM7aEAN+g9cP/m11NzdIhEjXvUupfwLIjXEw5JEkPMznc5QBkbPUe0LOfMw==" />
</div>
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ScriptManager1', 'form1', ['tUpdatePanel1','UpdatePanel1'], ['btnSubmit','btnSubmit'], [], 90, '');
//]]>
</script>

        <div id="UpdatePanel1">
	
                <!-- Header : START -->
                

<header class="header-style-1">
    <!-- ============================================== TOP MENU ============================================== -->
    <div class="top-bar animate-dropdown">
        <div class="container">
            <div class="header-top-inner">
                <div class="cnt-account" style="color: darkblue;">
                    
                    <script>
                        var blink_speed = 500;
                        var t = setInterval(function () {
                            var ele = document.getElementById('blinker');
                            ele.style.visibility = (ele.style.visibility == 'hidden' ? '' : 'hidden');
                        }, blink_speed);
                    </script>
                    <a id="blinker" href="https://anyror.gujarat.gov.in/" target="_blank">૭ / ૧૨ ના ઉતારા મેળવવા માટે અહિંયા ક્લિક કરો. </a>
					<a id="blinker" href="http://epaper.divyabhaskar.co.in/" target="_blank">કૃપા કરીને અહીં ક્લિક કરો અને અખબાર જુઓ </a>
					
                </div>
                <!-- /.cnt-account -->

                
                <!-- /.cnt-cart -->
                <div class="clearfix"></div>
            </div>
            <!-- /.header-top-inner -->
        </div>
        <!-- /.container -->
    </div>
    <!-- /.header-top -->
    <!-- ============================================== TOP MENU : END ============================================== -->
    <div class="main-header">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-9 logo-holder">
                    <div class="logo">
                        <a href="index.php">
                             <p><font size="6"> અજરાપુરા ગ્રામ પંચાયત</font></p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-3 social">
                    <ul class="link" style="margin-top: 20px;">
                        <li class="instagram pull-right"><a target="_blank" rel="nofollow" href="https://www.instagram.com/" title="Instagram"></a></li>
                        <li class="tw pull-right"><a target="_blank" rel="nofollow" href="https://twitter.com/" title="Twitter"></a></li>
                        <li class="fb pull-right"><a target="_blank" rel="nofollow" href="https://www.facebook.com/" title="Facebook"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="header-nav animate-dropdown">
        <div class="container">
            <div class="yamm navbar navbar-default" role="navigation">
                <div class="navbar-header">
                    <button data-target="#mc-horizontal-menu-collapse" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                        <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
                    </button>
                </div>
                <div class="nav-bg-class">
                    <div class="navbar-collapse collapse" id="mc-horizontal-menu-collapse">
                        <div class="nav-outer">
                            <ul class="nav navbar-nav">
                                <li id="Header_A1" class="dropdown "><a href="index.php">મુખ્ય પૃષ્ઠ</a></li>
                                <li id="Header_A2" class="dropdown"><a href="history.php">ઈતિહાસ</a></li>
                                <li id="Header_A3" class="dropdown"><a href="dharohar.php">ધરોહર</a></li>
                                <li id="Header_A4" class="dropdown"><a href="activities.php">પ્રવ્રુતિઓ</a></li>
                                <li id="Header_A13" class="dropdown"><a href="achievements.php">સિદ્ધિઓ</a> </li>
                                <li id="Header_A5" class="dropdown"><a href="javascript:void(0);" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown">પદાધિકારી</a>
                                    <ul class="dropdown-menu pages">
                                        <li>
                                            <div class="yamm-content">
                                                <div class="row">
                                                    <div class="col-xs-12 col-menu">
                                                        <ul class="links">
                                                            <li><a href="sabhya.php">પંચાયત</a></li>
                                                            <li><a href="javascript:void(0);">જાહેર સંસ્થા</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li id="Header_A6" class="dropdown"><a href="govproject.php">યોજનાઓ</a> </li>
                                <li id="Header_A7" class="dropdown"><a href="development.php">વિકાસના કામ</a> </li>
                                <li id="Header_A8" class="dropdown"><a href="bloodgroup.php">બ્લડ ગ્રુપની માહિતી</a> </li>
                                <li id="Header_A9" class="dropdown"><a href="akarni.php">મિલ્કત આકરણી</a> </li>
                                <li id="Header_A10" class="active"><a href="feedback.php">અભિપ્રાય</a> </li>
                                <li id="Header_A11" class="dropdown"><a href="complaint.php">ફરીયાદ</a> </li>
                                <li id="Header_A12" class="dropdown"><a href="contact.php">સંપર્ક</a> </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

                <!-- Header : END -->
                
<div class="breadcrumb">
    <div class="container">
        <div class="breadcrumb-inner">
            <ul class="list-inline list-unstyled">
                
            </ul>
        </div>
    </div>
</div>

                <!-- Content : START -->
                <div class="body-content">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-9 contact-form">
                                <div class="col-md-12 heading-title outer-bottom-small">
                                    <h2>અભિપ્રાય</h2>
                                </div>
                                <div class="col-md-12 outer-bottom-small">
                                    <p style="color:red;">નોંધ :- તમરો અભિપ્રાય ફક્ત ગામ અને ગામના વિકાસ માટેજ હોવો જોઈએ.</p>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="info-title">નામ <span>*</span></label>
                                        <input name="txtName" type="text" maxlength="500" id="txtName" class="form-control unicase-form-control text-input" required="" placeholder="Full Name" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="info-title">મોબાઈલ નંબર <span>*</span></label>
                                        <input name="txtMobile" type="text" maxlength="15" id="txtMobile" class="form-control unicase-form-control text-input" required="" placeholder="Mobile No." />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="info-title">ગામ / શહેરનું નામ <span>*</span></label>
                                        <input name="txtCity" type="text" maxlength="150" id="txtCity" class="form-control unicase-form-control text-input" required="" placeholder="Village Name" />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="info-title" for="exampleInputComments">અભિપ્રાય <span>*</span></label>
                                        <textarea name="txtMessage" rows="5" cols="20" id="txtMessage" class="form-control unicase-form-control" required="" placeholder="Message">
</textarea>
                                    </div>
                                </div>
                                <div class="col-md-12 outer-bottom-small m-t-20">
                                    <input type="submit" name="btnSubmit" value="Send" id="btnSubmit" class="btn-upper btn btn-primary checkout-page-button" />
                                </div>
                                <div class="col-md-12 m-t-20">
                                    <span id="lblMessage" class="info-title" style="font-size:15pt;"></span>
                                </div>
                            </div>
                            <!-- Sidebar : START -->
                            
<div class="col-xs-12 col-sm-12 col-md-3 sidebar">
    <div class="sidebar-widget hot-deals wow fadeInUp outer-bottom-xs">
        <h3 class="section-title">માનનીય</h3>
        <div class="owl-carousel sidebar-carousel custom-carousel owl-theme outer-top-ss">
		<?php
												if (!empty($minister_data)) {
										foreach ($minister_data as $val) {
														?>
            <div class="item">
                <div class="products">
                    <div class="hot-deal-wrapper">
                        <div class="image">
                            <img src="images/banner/<?php echo $val['tImage']; ?>" alt="મુખ્ય મંત્રી" />
                        </div>
                    </div>
                    <div class="product-info text-left m-t-20">
                        <p><?php echo $val['minister_category']; ?>,</p>
                        <div class="product-price">
                            <span class="price"><?php echo $val['minister_name']; ?></span>
                        </div>
                    </div>
                </div>
            </div>
			<?php
										}
								}
														?>
            
            
        </div>
    </div>
	
    <div class="sidebar-widget product-tag wow fadeInUp outer-bottom-xs">
        <h3 class="section-title">Latest News</h3>
        <div class="sidebar-widget-body outer-top-xs">
            <div class="tag-list">
                <marquee id="scroll_news" behavior="scroll" direction="up" scrollamount="2">
                    <?php
												if (!empty($news_data)) {
										foreach ($news_data as $val) {
														?>
                            <div onMouseOver="document.getElementById('scroll_news').stop();" onMouseOut="document.getElementById('scroll_news').start();">
                                <a class="item" title="<?php echo $val['news_name']; ?>" href="govproject.html" target="_blank"><?php echo $val['news_name']; ?></a>
                            </div>
							<?php
										}
								}
														?>
                        
                </marquee>
            </div>
        </div>
    </div>
	
    <!----------- Testimonials------------->
    <div class="sidebar-widget wow fadeInUp outer-top-vs outer-bottom-vs">
        <div id="testimonial" class="advertisement">
            
                    <div class="item">
                        <div class="testimonials"><em>"</em>ગામનો વિકાસ અને ગામ માં ટેકનોલોજી એકદમ અધતન છે.<em>"</em></div>
                        <div class="clients_author">MAYUR<span>AJARAPURA</span> </div>
                    </div>
                
        </div>
    </div>
    
</div>

                            <!--Sidebar : END-->
                        </div>
                    </div>
                </div>
                <br />
            
</div>
        <!-- Footer : START -->
        
<footer id="footer" class="footer color-bg">
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">વિકાસના કામ માટે ડોનેશન</h4>
                    </div>
                    <div class="module-body">
                        <ul class="toggle-footer" style="">
                            <li class="media">
                                <div class="media-body">
                                    <p style="color:#ffffff;"><b>BANK NAME : </b>BANK OF BARODA</p>
                                </div>
                            </li>

                            <li class="media">
                                <div class="media-body">
                                    <p style="color:#ffffff;"><b>A/C NO : </b>***************</p>
                                </div>
                            </li>

                            <li class="media">
                                <div class="media-body">
                                    <p style="color:#ffffff;"><b>IFSC CODE : </b>BARBORANCHH</p>
                                </div>
                            </li>

                        </ul>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">ગવર્મેન્ટ વેબ સાઈટ</h4>
                    </div>
                    <div class="module-body">
                        <ul class="list-unstyled">
                            <li class="first"><a title="ગ્રામ ગૃહનિર્માણ અને ગ્રામ વિકાસ વિભાગ" href="https://panchayat.gujarat.gov.in/panchayatvibhag/">ગ્રામ ગૃહનિર્માણ અને ગ્રામ વિકાસ વિભાગ</a></li>
                            <li class="first"><a title="ભારતીય ડાક" href="https://www.indiapost.gov.in/">ભારતીય ડાક</a></li>
                            <li class="first"><a title="નર્મદા, જળ સંપત્તિ, પાણી પુરવઠા અને કલ્પસર વિભાગ" href="https://guj-nwrws.gujarat.gov.in/">નર્મદા, જળ સંપત્તિ, પાણી પુરવઠા અને કલ્પસર વિભાગ</a></li>
                            <li class="first"><a title="ગુજરાત ઊર્જા વિકાસ નિગમ લિમિટેડ" href="http://www.gseb.com/">ગુજરાત ઊર્જા વિકાસ નિગમ લિમિટેડ</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-2">
                    <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">ગવર્મેન્ટ વેબ સાઈટ</h4>
                    </div>
                    <div class="module-body">
                        <ul class="list-unstyled">
                            <li class="first"><a title="મતદાર કાર્ડ" href="https://ceo.gujarat.gov.in/">ઓનલાઈન મતદાર કાર્ડ</a></li>
                            <li class="first"><a title="આધાર કાર્ડ" href="https://ceo.gujarat.gov.in/">ઓનલાઈન આધાર કાર્ડ</a></li>
                            <li class="first"><a title="Any ROR" href="https://anyror.gujarat.gov.in/">Any ROR</a></li>
                            <li class="first"><a title="i-ખેડૂત" href="https://ikhedut.gujarat.gov.in/">i-ખેડૂત</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3">
                     <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">તત્કાલીન સુવિધાના નંબર</h4>
                    </div>
                    <div class="module-body">
                        <ul class="list-unstyled">
                            <li class="first"><a href="javascript:void(0);" title="વિજાપુર તાલુકા પોલીસ સ્ટેશન">પોલીસ સ્ટેશન : (02763) 220016</a></li>
                            <li class="first"><a href="javascript:void(0);" title="નગરપાલિકા ફાયર  સ્ટેશન">નગરપાલિકા Fire : (02763) 220020</a></li>
                            <li class="first"><a href="javascript:void(0);" title="એ.પી.એમ.સી ફાયર સ્ટેશન">APMC Fire : 220190, 9429197651, 52</a></li>
                            <li class="first"><a href="javascript:void(0);" title="એ.પી.એમ.સી એમ્બુલન્સ">APMC Ambulance : 9824106796</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-bar">
        <div class="container">
            <div class="col-xs-12 col-sm-12 no-padding">
                <div class="clearfix">
                    <p style="color:white; text-align:center;">ALL RIGHTS RESERVED BY AJARAPURA GRAM PANCHAYAT <sup style="color:white;">®</sup></a> <br/>  
					<script type="text/javascript" src="http://counter.websiteout.net/js/15/0/532/1"></script></p>
                </div>
            </div>
        </div>
    </div>
</footer>

        <!-- Footer : END -->
    </form>
    

<script src="assets/js/jquery-1.11.1.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/bootstrap-hover-dropdown.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/echo.min.js"></script>
<script src="assets/js/jquery.easing-1.3.min.js"></script>
<script src="assets/js/bootstrap-slider.min.js"></script>
<script src="assets/js/jquery.rateit.min.js"></script>
<script type="text/javascript" src="assets/js/lightbox.min.js"></script>
<script src="assets/js/bootstrap-select.min.js"></script>
<script src="assets/js/wow.min.js"></script>
<script src="assets/js/scripts.js"></script>

</body>

<!-- Mirrored from www.jepurpanchayat.com/feedback.aspx by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 04 May 2018 10:45:47 GMT -->
</html>
