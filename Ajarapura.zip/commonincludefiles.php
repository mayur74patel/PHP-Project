<?php 
global $appname;
$appname = "Fantastic Services";

include 'connection.php';
include 'constant.php';
require 'commonfunctions.php';
global $conn;

?>