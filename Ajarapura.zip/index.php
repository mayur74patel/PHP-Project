<?php
session_start();
include 'commonincludefiles.php';
global $conn;
$sa_data = array();
$sa_data = getAllsarpanchData();
$d_sa_data = array();
$d_sa_data = getAlld_sarpanchData();
$talati_data = array();
$talati_data = getAlltalatiData();
$gram_sevak_data = array();
$gram_sevak_data = getAllgram_sevakData();
$history_data = array();
$history_data = getAllhistoryData();
$minister_data = array();
$minister_data = getAllministerData();
$news_data = array();
$news_data = getAllnewsData();
$banner_data = array();
$banner_data = getAllcategoryData();
?>
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from www.jepurpanchayat.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 04 May 2018 10:42:58 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <!-- Meta -->
    <meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" /><meta name="description" /><meta name="author" /><meta name="keywords" content="Jepur Gram Panchayat Vijapur, Gram Panchayat Jepur, Online Jepur Panchayat, Jepur Vijapur, Gram Panchayat Vijapur, Gram Panchayat Software, Jepur Vijapur Mehsana, Gujarat" /><meta name="robots" content="all" /><title>
	અજરાપુરા ગ્રામ પંચાયત
</title>

    <!-- Style Sheet : START -->
    

<!-- Bootstrap Core CSS -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
<!-- Customizable CSS -->
<link rel="stylesheet" href="assets/css/main.css" />
<link rel="stylesheet" href="assets/css/blue.css" />
<link rel="stylesheet" href="assets/css/owl.carousel.css" />
<link rel="stylesheet" href="assets/css/owl.transitions.css" />
<link rel="stylesheet" href="assets/css/animate.min.css" />
<link rel="stylesheet" href="assets/css/rateit.css" />
<link rel="stylesheet" href="assets/css/bootstrap-select.min.css" />
<link href="assets/css/lightbox.css" rel="stylesheet">

<!-- Icons/Glyphs -->
<link rel="stylesheet" href="assets/css/font-awesome.css" />

<!-- Fonts -->
<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css' />
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,600italic,700,700italic,800' rel='stylesheet' type='text/css' />
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />



    <!-- Style Sheet : START -->
</head>
<body class="cnt-home">
    <form method="post" action="#" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUJMjcxNTA2MjczD2QWAgIDD2QWBAIBD2QWAgIBDxYCHgVjbGFzcwUGYWN0aXZlZAIFD2QWBAIBDxYCHgtfIUl0ZW1Db3VudAIBFgJmD2QWAmYPFQO3AeCqteCqsOCrjeCqtyA6IOCrqOCrpuCrp+Crri3gq6fgq68g4Kqu4Kq+4Kqf4KuHIOCqluCrh+CqpOCrgOCqteCqvuCqoeCrgOCqqOCrgCDgqrXgqr/gqrXgqr/gqqcg4Kqv4KuL4Kqc4Kqo4Kq+4KqT4Kqo4KuAIOCqk+CqqOCqsuCqvuCqh+CqqCDgqoXgqrDgqpzgq4DgqpMg4Kqu4Kq+4Kqf4KuHIENsaWNrIOCqleCqsOCriy1odHRwOi8vd3d3LmplcHVycGFuY2hheWF0LmNvbS9nb3Zwcm9qZWN0LmFzcHi3AeCqteCqsOCrjeCqtyA6IOCrqOCrpuCrp+Crri3gq6fgq68g4Kqu4Kq+4Kqf4KuHIOCqluCrh+CqpOCrgOCqteCqvuCqoeCrgOCqqOCrgCDgqrXgqr/gqrXgqr/gqqcg4Kqv4KuL4Kqc4Kqo4Kq+4KqT4Kqo4KuAIOCqk+CqqOCqsuCqvuCqh+CqqCDgqoXgqrDgqpzgq4DgqpMg4Kqu4Kq+4Kqf4KuHIENsaWNrIOCqleCqsOCri2QCAw8WAh8BAgEWAmYPZBYCZg8VA3vgqpfgqr7gqq7gqqjgq4sg4Kq14Kq/4KqV4Kq+4Kq4IOCqheCqqOCrhyDgqpfgqr7gqq4g4Kqu4Kq+4KqCIOCqn+Crh+CqleCqqOCri+CqsuCri+CqnOCrgCDgqo/gqpXgqqbgqq4g4KqF4Kqn4Kqk4KqoIOCqm+Crhy4GVEFSRVNIB01FSFNBTkFkZMJZRI5lChoISLuKL3F0PZ4fTrZP7FXXbMDaP/xKMB+J" />
</div>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="90059987" />
</div>
        <!-- Header : START -->
        

<header class="header-style-1">
    <!-- ============================================== TOP MENU ============================================== -->
    <div class="top-bar animate-dropdown">
        <div class="container">
            <div class="header-top-inner">
                <div class="cnt-account" style="color: darkblue;">
                    
                    <script>
                        var blink_speed = 500;
                        var t = setInterval(function () {
                            var ele = document.getElementById('blinker');
                            ele.style.visibility = (ele.style.visibility == 'hidden' ? '' : 'hidden');
                        }, blink_speed);
                    </script>
                    <a id="blinker" href="https://anyror.gujarat.gov.in/" target="_blank">૭ / ૧૨ ના ઉતારા મેળવવા માટે અહિંયા ક્લિક કરો. </a>
					&nbsp &nbsp<a id="blinker" href="http://epaper.divyabhaskar.co.in/" target="_blank">કૃપા કરીને અહીં ક્લિક કરો અને અખબાર જુઓ </a>
					
                </div>
                <!-- /.cnt-account -->

                
                <!-- /.cnt-cart -->
                <div class="clearfix"></div>
            </div>
            <!-- /.header-top-inner -->
        </div>
        <!-- /.container -->
    </div>
    <!-- /.header-top -->
    <!-- ============================================== TOP MENU : END ============================================== -->
    <div class="main-header">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-9 logo-holder">
                    <div class="logo">
                        <a href="index.php">
                           <p><font size="6"> અજરાપુરા ગ્રામ પંચાયત</font></p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-3 social">
                    <ul class="link" style="margin-top: 20px;">
                        <li class="instagram pull-right"><a target="_blank" rel="nofollow" href="https://www.instagram.com/" title="Instagram"></a></li>
                        <li class="tw pull-right"><a target="_blank" rel="nofollow" href="https://twitter.com/" title="Twitter"></a></li>
                        <li class="fb pull-right"><a target="_blank" rel="nofollow" href="https://www.facebook.com/" title="Facebook"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="header-nav animate-dropdown">
        <div class="container">
            <div class="yamm navbar navbar-default" role="navigation">
                <div class="navbar-header">
                    <button data-target="#mc-horizontal-menu-collapse" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                        <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
                    </button>
                </div>
                <div class="nav-bg-class">
                    <div class="navbar-collapse collapse" id="mc-horizontal-menu-collapse">
                        <div class="nav-outer">
                            <ul class="nav navbar-nav">
                                <li id="Header_A1" class="active"><a href="index.php">મુખ્ય પૃષ્ઠ</a></li>
                                <li id="Header_A2" class="dropdown"><a href="history.php">ઈતિહાસ</a></li>
                                <li id="Header_A3" class="dropdown"><a href="dharohar.php">ધરોહર</a></li>
                                <li id="Header_A4" class="dropdown"><a href="activities.php">પ્રવ્રુતિઓ</a></li>
                                <li id="Header_A13" class="dropdown"><a href="achievements.php">સિદ્ધિઓ</a> </li>
                                <li id="Header_A5" class="dropdown"><a href="javascript:void(0);" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown">પદાધિકારી</a>
                                    <ul class="dropdown-menu pages">
                                        <li>
                                            <div class="yamm-content">
                                                <div class="row">
                                                    <div class="col-xs-12 col-menu">
                                                        <ul class="links">
                                                            <li><a href="sabhya.php">પંચાયત</a></li>
                                                            <li><a href="javascript:void(0);">જાહેર સંસ્થા</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li id="Header_A6" class="dropdown"><a href="govproject.php">યોજનાઓ</a> </li>
                                <li id="Header_A7" class="dropdown"><a href="development.php">વિકાસના કામ</a> </li>
                                <li id="Header_A8" class="dropdown"><a href="bloodgroup.php">બ્લડ ગ્રુપની માહિતી</a> </li>
                                <li id="Header_A9" class="dropdown"><a href="akarni.php">મિલ્કત આકરણી</a> </li>
                                <li id="Header_A10" class="dropdown"><a href="feedback.php">અભિપ્રાય</a> </li>
                                <li id="Header_A11" class="dropdown"><a href="complaint.php">ફરીયાદ</a> </li>
                                <li id="Header_A12" class="dropdown"><a href="contact.php">સંપર્ક</a> </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

        <!-- Header : END -->
        
<div class="breadcrumb">
    <div class="container">
        <div class="breadcrumb-inner">
            <ul class="list-inline list-unstyled">
                
            </ul>
        </div>
    </div>
</div>

        <!-- Content : START -->
        <div class="body-content outer-top-xs" id="top-banner-and-menu">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-9 homebanner-holder">
                        <div id="hero">
                            <div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">
							<?php
                                if (!empty($banner_data)) {
										foreach ($banner_data as $val) {
														?>
                                <div class="item" style="background-image: url(images/banner/<?php echo $val['tImage']; ?>);">
                                    <div class="container-fluid">
                                        <div class="caption bg-color vertical-center text-left">
                                            
                                        </div>
                                    </div>
                                </div>
								<?php
										}
								}
														?>
                                
                            </div>
                        </div>
                        <div id="product-tabs-slider" class="scroll-tabs outer-top-vs wow fadeInUp">
                            <div class="more-info-tab clearfix ">
                                <h3 class="new-product-title pull-left">મુખ્ય પદાધિકારી</h3>
                            </div>
                            <div class="tab-content outer-top-xs">
                                <div class="tab-pane in active" id="all">
                                    <div class="product-slider">
                                        <div class="owl-carousel home-owl-carousel custom-carousel owl-theme" data-item="4">
                                            <div class="item item-carousel">
                                                <div class="products">
												<?php
                                if (!empty($sa_data)) {
										foreach ($sa_data as $val) {
														?>
                                                    <div class="product">
                                                        <div class="product-image">
                                                            <div class="image">
                                                                <a href="javascript:void(0);">
                                                                    <img src="images/banner/<?php echo $val['tImage']; ?>" alt="	" height="185" width="42"/></a>
                                                            </div>
                                                        </div>
														
                                                        <div class="product-info text-left">
                                                            <h3 class="name"><a href="javascript:void(0);">સરપંચશ્રી</a></h3>
                                                            <div class="product-price"><span class="price"><?php echo $val['sarpanch_name']; ?></span></div>
															<div class="description">+૯૧-<?php echo $val['sarpanch_no']; ?></div>
                                                        </div>
                                                        <div class="cart clearfix animate-effect">
                                                            <div class="action">
                                                                <ul class="list-unstyled">
                                                                    <li class="lnk">
                                                                        <a class="add-to-cart" href="<?php echo $val['sarpanch_fb']; ?>" target="_blank" title="Facebook">
                                                                            <i class="fa fa-facebook"></i>
                                                                        </a>
                                                                    </li>
                                                                    <li class="lnk">
                                                                        <a class="add-to-cart" href="<?php echo $val['sarpanch_twitter']; ?>" target="_blank" title="Twitter">
                                                                            <i class="fa fa-twitter"></i>
                                                                        </a>
                                                                    </li>
                                                                    <li class="lnk">
                                                                        <a class="add-to-cart" href="<?php echo $val['sarpanch_insta']; ?>" target="_blank" title="Instagram">
                                                                            <i class="fa fa-instagram"></i>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
													<?php
										}
								}
														?>
								
                                                </div>
                                            </div>
                                            <div class="item item-carousel">
                                                <div class="products">
												<?php
                                if (!empty($d_sa_data)) {
										foreach ($d_sa_data as $val) {
														?>
                                                    <div class="product">
                                                        <div class="product-image">
                                                            <div class="image">
                                                                <a href="javascript:void(0);">
                                                                    <img src="images/banner/<?php echo $val['tImage']; ?>" alt="" height="185" width="42" /></a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-left">
                                                            <h3 class="name"><a href="javascript:void(0);">ઉપ સરપંચશ્રી</a></h3>
                                                            <div class="product-price"><span class="price"><?php echo $val['sarpanch_name']; ?></span></div>
                                                            <div class="description">+૯૧-<?php echo $val['sarpanch_no']; ?></div>
                                                        </div>
                                                        <div class="cart clearfix animate-effect">
                                                            <div class="action">
                                                                <ul class="list-unstyled">
                                                                    <li class="lnk">
                                                                        <a class="add-to-cart" href="<?php echo $val['sarpanch_fb']; ?>http://www.facebook.com/" target="_blank" title="Facebook">
                                                                            <i class="fa fa-facebook"></i>
                                                                        </a>
                                                                    </li>
                                                                    <li class="lnk">
                                                                        <a class="add-to-cart" href="<?php echo $val['sarpanch_twitter']; ?>" title="Twitter">
                                                                            <i class="fa fa-twitter"></i>
                                                                        </a>
                                                                    </li>
                                                                    <li class="lnk">
                                                                        <a class="add-to-cart" href="<?php echo $val['sarpanch_insta']; ?>" title="Instagram">
                                                                            <i class="fa fa-instagram"></i>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
													<?php
										}
								}
														?>
                                                </div>
                                            </div>
                                            <div class="item item-carousel">
                                                <div class="products">
												<?php
												if (!empty($talati_data)) {
										foreach ($talati_data as $val) {
														?>
                                                    <div class="product">
                                                        <div class="product-image">
                                                            <div class="image">
                                                                <a href="javascript:void(0);">
                                                                    <img src="images/banner/<?php echo $val['tImage']; ?>" alt="" height="185" width="42"/></a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-left">
                                                            <h3 class="name"><a href="#">તલાટી કમ મંત્રી</a></h3>
                                                            <div class="product-price"><span class="price"><?php echo $val['sarpanch_name']; ?></span></div>
                                                            <div class="description">+૯૧-<?php echo $val['sarpanch_no']; ?></div>
                                                        </div>
                                                        <div class="cart clearfix animate-effect">
                                                            <div class="action">
                                                                <ul class="list-unstyled">
                                                                    <li class="lnk">
                                                                        <a class="add-to-cart" href="<?php echo $val['sarpanch_fb']; ?>" target="_blank" title="Facebook">
                                                                            <i class="fa fa-facebook"></i>
                                                                        </a>
                                                                    </li>
                                                                    <li class="lnk">
                                                                        <a class="add-to-cart" href="<?php echo $val['sarpanch_twitter']; ?>" title="Twitter">
                                                                            <i class="fa fa-twitter"></i>
                                                                        </a>
                                                                    </li>
                                                                    <li class="lnk">
                                                                        <a class="add-to-cart" href="<?php echo $val['sarpanch_insta']; ?>" title="Instagram">
                                                                            <i class="fa fa-instagram"></i>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
													<?php
										}
								}
														?>
                                                </div>
                                            </div>
                                            <div class="item item-carousel">
                                                <div class="products">
												<?php
												if (!empty($gram_sevak_data)) {
										foreach ($gram_sevak_data as $val) {
														?>
                                                    <div class="product">
                                                        <div class="product-image">
                                                            <div class="image">
                                                                <a href="javascript:void(0);">
                                                                    <img src="images/banner/<?php echo $val['tImage']; ?>" alt="" height="185" width="42"/></a>
                                                            </div>
                                                        </div>
                                                        <div class="product-info text-left">
                                                            <h3 class="name"><a href="javascript:void(0);">ગ્રામસેવક</a></h3>
                                                            <div class="product-price"><span class="price"><?php echo $val['sarpanch_name']; ?></span></div>
                                                            <div class="description">+૯૧-<?php echo $val['sarpanch_no']; ?></div>
                                                        </div>
                                                        <div class="cart clearfix animate-effect">
                                                            <div class="action">
                                                                <ul class="list-unstyled">
                                                                    <li class="lnk">
                                                                        <a class="add-to-cart" href="<?php echo $val['sarpanch_fb']; ?>" target="_blank" title="Facebook">
                                                                            <i class="fa fa-facebook"></i>
                                                                        </a>
                                                                    </li>
                                                                    <li class="lnk">
                                                                        <a class="add-to-cart" href="<?php echo $val['sarpanch_twitter']; ?>" title="Twitter">
                                                                            <i class="fa fa-twitter"></i>
                                                                        </a>
                                                                    </li>
                                                                    <li class="lnk">
                                                                        <a class="add-to-cart" href="<?php echo $val['sarpanch_insta']; ?>" title="Instagram">
                                                                            <i class="fa fa-instagram"></i>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
													<?php
										}
								}
														?>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
						<?php
												if (!empty($history_data)) {
										foreach ($history_data as $val) {
														?>
                        <div class="blog-page">
                            <div class="blog-post wow fadeInUp">
                                <h1>અજરાપુરા ગામની લોક વાયકા</h1>
                                <p style="text-align: justify;"> <?php echo $val['history_story']; ?><a class="contact-form" href="javascript:void(0);">અજરાપુરા</a> . ગામમાં સૌથી પહેલાં જે મહોલ્લાની શરૂઆત થઇ તેને પટેલ વાસ મહોલ્લો નામ આપવામાં આવ્યું. આમ આ ગામ સમયની સાથે ખેતી ક્ષેત્રે અને શિક્ષણક્ષેત્રે ખુબ સારી પ્રગતિ કરતુ ગયું. ગામના લોકોનો મુખ્ય વ્યવસાય ખેતી અને પશુપાલન છે. ગામના લોકોનો મુખ્ય ઉદ્યોગ તમાકુનો છે. તદઉપરાંત અમુક લોકો ઓઈલમિલ તથા જીનીંગના વ્યવસાય ક્ષેત્રે જેડાયેલા છે. આ ગામની રાજકીય છાપ પણ ઘણી સારી છે.    </p>
                            </div>
                        </div>
						<?php
										}
								}
														?>
                        <div class="clearfix blog-pagination filters-container  wow fadeInUp" style="padding: 0px; background: none; box-shadow: none; margin-top: 15px; border: none">
                            <div class="text-right">
                                <div class="pagination-container">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Sidebar : START -->
                    

<div class="col-xs-12 col-sm-12 col-md-3 sidebar">
    <div class="sidebar-widget hot-deals wow fadeInUp outer-bottom-xs">
        <h3 class="section-title">માનનીય</h3>
        <div class="owl-carousel sidebar-carousel custom-carousel owl-theme outer-top-ss">
		<?php
												if (!empty($minister_data)) {
										foreach ($minister_data as $val) {
														?>
            <div class="item">
                <div class="products">
                    <div class="hot-deal-wrapper">
                        <div class="image">
                            <img src="images/banner/<?php echo $val['tImage']; ?>" alt="મુખ્ય મંત્રી" />
                        </div>
                    </div>
                    <div class="product-info text-left m-t-20">
                        <p><?php echo $val['minister_category']; ?>,</p>
                        <div class="product-price">
                            <span class="price"><?php echo $val['minister_name']; ?></span>
                        </div>
                    </div>
                </div>
            </div>
			<?php
										}
								}
														?>
            
            
        </div>
    </div>
	
    <div class="sidebar-widget product-tag wow fadeInUp outer-bottom-xs">
        <h3 class="section-title">Latest News</h3>
        <div class="sidebar-widget-body outer-top-xs">
            <div class="tag-list">
                <marquee id="scroll_news" behavior="scroll" direction="up" scrollamount="2">
                    <?php
												if (!empty($news_data)) {
										foreach ($news_data as $val) {
														?>
                            <div onMouseOver="document.getElementById('scroll_news').stop();" onMouseOut="document.getElementById('scroll_news').start();">
                                <a class="item" title="<?php echo $val['news_name']; ?>" href="govproject.html" target="_blank"><?php echo $val['news_name']; ?></a>
                            </div>
							<?php
										}
								}
														?>
                        
                </marquee>
            </div>
        </div>
    </div>
	
    <!----------- Testimonials------------->
    <div class="sidebar-widget wow fadeInUp outer-top-vs outer-bottom-vs">
        <div id="testimonial" class="advertisement">
            
                    <div class="item">
                        <div class="testimonials"><em>"</em>ગામનો વિકાસ અને ગામ માં ટેકનોલોજી એકદમ અધતન છે.<em>"</em></div>
                        <div class="clients_author">MAYUR<span>AJARAPURA</span> </div>
                    </div>
                
        </div>
    </div>
    
</div>

                    <!--Sidebar : END-->
                </div>
                <div id="brands-carousel" class="logo-slider wow fadeInUp">
                    <div class="logo-slider-inner">
                        <div id="brand-slider" class="owl-carousel brand-slider custom-carousel owl-theme">
                            <div class="item">
                                <img data-echo="assets/images/brands/brand5.png" src="assets/images/blank.gif" alt="" />
                            </div>
                            <div class="item m-t-15">
                                <img data-echo="assets/images/brands/brand1.png" src="assets/images/blank.gif" alt="" />
                            </div>
                            <div class="item m-t-10">
                                <img data-echo="assets/images/brands/brand2.png" src="assets/images/blank.gif" alt="" />
                            </div>
                            <div class="item">
                                <img data-echo="assets/images/brands/brand3.png" src="assets/images/blank.gif" alt="" />
                            </div>
                            <div class="item">
                                <img data-echo="assets/images/brands/brand6.png" src="assets/images/blank.gif" alt="" />
                            </div>
                            <div class="item">
                                <img data-echo="assets/images/brands/brand4.png" src="assets/images/blank.gif" alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Content : END -->
        <!-- Footer : START -->
        
<footer id="footer" class="footer color-bg">
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">વિકાસના કામ માટે ડોનેશન</h4>
                    </div>
                    <div class="module-body">
                        <ul class="toggle-footer" style="">
                            <li class="media">
                                <div class="media-body">
                                    <p style="color:#ffffff;"><b>BANK NAME : </b>BANK OF BARODA</p>
                                </div>
                            </li>

                            <li class="media">
                                <div class="media-body">
                                    <p style="color:#ffffff;"><b>A/C NO : </b>**************</p>
                                </div>
                            </li>

                            <li class="media">
                                <div class="media-body">
                                    <p style="color:#ffffff;"><b>IFSC CODE : </b>BARBORANCHH</p>
                                </div>
                            </li>

                        </ul>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">ગવર્મેન્ટ વેબ સાઈટ</h4>
                    </div>
                    <div class="module-body">
                        <ul class="list-unstyled">
                            <li class="first"><a title="ગ્રામ ગૃહનિર્માણ અને ગ્રામ વિકાસ વિભાગ" href="https://panchayat.gujarat.gov.in/panchayatvibhag/">ગ્રામ ગૃહનિર્માણ અને ગ્રામ વિકાસ વિભાગ</a></li>
                            <li class="first"><a title="ભારતીય ડાક" href="https://www.indiapost.gov.in/">ભારતીય ડાક</a></li>
                            <li class="first"><a title="નર્મદા, જળ સંપત્તિ, પાણી પુરવઠા અને કલ્પસર વિભાગ" href="https://guj-nwrws.gujarat.gov.in/">નર્મદા, જળ સંપત્તિ, પાણી પુરવઠા અને કલ્પસર વિભાગ</a></li>
                            <li class="first"><a title="ગુજરાત ઊર્જા વિકાસ નિગમ લિમિટેડ" href="http://www.gseb.com/">ગુજરાત ઊર્જા વિકાસ નિગમ લિમિટેડ</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-2">
                    <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">ગવર્મેન્ટ વેબ સાઈટ</h4>
                    </div>
                    <div class="module-body">
                        <ul class="list-unstyled">
                            <li class="first"><a title="મતદાર કાર્ડ" href="https://ceo.gujarat.gov.in/">ઓનલાઈન મતદાર કાર્ડ</a></li>
                            <li class="first"><a title="આધાર કાર્ડ" href="https://ceo.gujarat.gov.in/">ઓનલાઈન આધાર કાર્ડ</a></li>
                            <li class="first"><a title="Any ROR" href="https://anyror.gujarat.gov.in/">Any ROR</a></li>
                            <li class="first"><a title="i-ખેડૂત" href="https://ikhedut.gujarat.gov.in/">i-ખેડૂત</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3">
                     <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">તત્કાલીન સુવિધાના નંબર</h4>
                    </div>
                    <div class="module-body">
                        <ul class="list-unstyled">
                            <li class="first"><a href="javascript:void(0);" title="વિજાપુર તાલુકા પોલીસ સ્ટેશન">પોલીસ સ્ટેશન : (02763) 220016</a></li>
                            <li class="first"><a href="javascript:void(0);" title="નગરપાલિકા ફાયર  સ્ટેશન">નગરપાલિકા Fire : (02763) 220020</a></li>
                            <li class="first"><a href="javascript:void(0);" title="એ.પી.એમ.સી ફાયર સ્ટેશન">APMC Fire : 220190, 9429197651, 52</a></li>
                            <li class="first"><a href="javascript:void(0);" title="એ.પી.એમ.સી એમ્બુલન્સ">APMC Ambulance : 9824106796</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-bar">
        <div class="container">
            <div class="col-xs-12 col-sm-12 no-padding">
                <div class="clearfix">
                    <p style="color:white; text-align:center;">ALL RIGHTS RESERVED BY AJARAPURA GRAM PANCHAYAT <sup style="color:white;">®</sup></a> <br/>  
					<script type="text/javascript" src="http://counter.websiteout.net/js/15/0/532/1"></script></p>
                </div>
            </div>
        </div>
    </div>
</footer>

        <!-- Footer : END -->
    </form>
    

<script src="assets/js/jquery-1.11.1.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/bootstrap-hover-dropdown.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/echo.min.js"></script>
<script src="assets/js/jquery.easing-1.3.min.js"></script>
<script src="assets/js/bootstrap-slider.min.js"></script>
<script src="assets/js/jquery.rateit.min.js"></script>
<script type="text/javascript" src="assets/js/lightbox.min.js"></script>
<script src="assets/js/bootstrap-select.min.js"></script>
<script src="assets/js/wow.min.js"></script>
<script src="assets/js/scripts.js"></script>

</body>

<!-- Mirrored from www.jepurpanchayat.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 04 May 2018 10:44:24 GMT -->
</html>
