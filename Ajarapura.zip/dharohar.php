<?php
session_start();
include 'commonincludefiles.php';
global $conn;
$sa_data = array();
$sa_data = getAllsarpanchData();
$d_sa_data = array();
$d_sa_data = getAlld_sarpanchData();
$talati_data = array();
$talati_data = getAlltalatiData();
$gram_sevak_data = array();
$gram_sevak_data = getAllgram_sevakData();
$history_data = array();
$history_data = getAllhistoryData();
$minister_data = array();
$minister_data = getAllministerData();
$news_data = array();
$news_data = getAllnewsData();
$place_data = array();
$place_data = getAllplaceData();
?>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from www.jepurpanchayat.com/dharohar.aspx by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 04 May 2018 10:44:44 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <!-- Meta -->
    <meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" /><meta name="description" /><meta name="author" /><meta name="keywords" content="Jepur Gram Panchayat Vijapur, Gram Panchayat Jepur, Online Jepur Panchayat, Jepur Vijapur, Gram Panchayat Vijapur, Gram Panchayat Software, Jepur Vijapur Mehsana, Gujarat" /><meta name="robots" content="all" /><title>
	અજરાપુરા ગ્રામ પંચાયત
</title>

    <!-- Style Sheet : START -->
    

<!-- Bootstrap Core CSS -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
<!-- Customizable CSS -->
<link rel="stylesheet" href="assets/css/main.css" />
<link rel="stylesheet" href="assets/css/blue.css" />
<link rel="stylesheet" href="assets/css/owl.carousel.css" />
<link rel="stylesheet" href="assets/css/owl.transitions.css" />
<link rel="stylesheet" href="assets/css/animate.min.css" />
<link rel="stylesheet" href="assets/css/rateit.css" />
<link rel="stylesheet" href="assets/css/bootstrap-select.min.css" />
<link href="assets/css/lightbox.css" rel="stylesheet">

<!-- Icons/Glyphs -->
<link rel="stylesheet" href="assets/css/font-awesome.css" />

<!-- Fonts -->
<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css' />
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,600italic,700,700italic,800' rel='stylesheet' type='text/css' />
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />



    <!-- Style Sheet : START -->
</head>
<body class="cnt-home">
    <form method="post" action="http://www.jepurpanchayat.com/dharohar.aspx" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUKMTczOTc2OTI5Ng9kFgICAw9kFgYCAQ9kFgICBQ8WAh4FY2xhc3MFBmFjdGl2ZWQCBQ8WAh4LXyFJdGVtQ291bnQCFRYqZg9kFgJmDxUFHmFzc2V0cy9pbWFnZXMvYmxvZy1wb3N0L3A4LmpwZyHgqqrgq43gqrDgqrXgq4fgqrbgqqbgq43gqrXgqr7gqrAh4Kqq4KuN4Kqw4Kq14KuH4Kq24Kqm4KuN4Kq14Kq+4KqwLOCquOCrjeCqpeCqvuCqquCqqOCqviDgqrjgqqjgq4cg4Kuo4Kum4Kum4KuvpAPgqpfgqr7gqq7gqqjgqr4g4Kqu4KuB4KqX4KqfIOCquOCqruCriyDgqoYg4Kqt4Kq14KuN4KqvIOCqquCrjeCqsOCqteCrh+CqtuCqpuCrjeCqteCqvuCqsCDgqqTgqr4u4KunL+Crpy/gq6jgq6bgq6bgq68g4Kqo4Kq+IOCqsOCri+CqnCDgqpfgqr7gqq7gqqjgqr4g4Kq44Kq+4Kqu4Kq+4Kqc4Kq/4KqVIOCqheCql+CrjeCqsOCqo+CrgCDgqoXgqqjgq4cg4Kqm4Kq+4Kqo4Kq14KuA4KqwIOCqtuCrjeCqsOCrgCDgqqrgqp/gq4fgqrIg4Kqw4Kq+4Kqu4Kq+4Kqt4Kq+4KqIIOCqquCrjeCqsOCqreCrgeCqpuCqvuCquCAo4KqX4KuL4Kqf4KuAKeCqjyDgqqzgqqjgqr7gqrXgq4Ag4KqG4Kqq4KuAIOCql+CqvuCqruCqqOCrhyDgqoXgqrDgq43gqqrgqqMg4KqV4Kqw4Kq14Kq+4Kqu4Kq+4KqCIOCqhuCqteCrjeCqr+CriyDgqrngqqTgq4suICBkAgEPZBYCZg8VBR9hc3NldHMvaW1hZ2VzL2Jsb2ctcG9zdC9wMTUuanBnMuCqnOCrh+CqquCrgeCqsCDgqpfgq43gqrDgqr7gqq4g4Kqq4KqC4Kqa4Kq+4Kqv4KqkMuCqnOCrh+CqquCrgeCqsCDgqpfgq43gqrDgqr7gqq4g4Kqq4KqC4Kqa4Kq+4Kqv4KqkLOCquOCrjeCqpeCqvuCqquCqqOCqviDgqrjgqqjgq4cg4Kun4Kuv4Kuu4KurpQLgqpzgq4fgqqrgq4HgqrAg4KqX4Kq+4KquIOCqhuCql+CqsuCri+CqoeCqruCqvuCqguCqpeCrgCDgqoXgqrLgqpcg4Kql4Kqv4KuB4KqCIOCqpOCrh+CqpeCrgCDgqpzgq4fgqqrgq4HgqrAg4KqX4Kq+4Kqu4Kqo4Kq+IOCqsuCri+CqleCri+CqqOCrgCDgqrjgq4HgqrXgqr/gqqfgqr4g4Kqu4Kq+4Kqf4KuHIOCrp+Crr+CrruCrq+CqruCqvuCqgiDgqpfgq43gqrDgqr7gqq7gqqrgqoLgqprgqr7gqq/gqqQg4Kqo4KuAIOCquOCrjeCqpeCqvuCqquCqqOCqviDgqpXgqrDgqrXgqr7gqq7gqr7gqoIg4KqG4Kq14KuALmQCAg9kFgJmDxUFHmFzc2V0cy9pbWFnZXMvYmxvZy1wb3N0L3A1LmpwZzXgqpfgq43gqrDgqr7gqq4g4Kq44Kqa4Kq/4Kq14Kq+4Kqy4KqvIOCqnOCrh+CqquCrgeCqsDXgqpfgq43gqrDgqr7gqq4g4Kq44Kqa4Kq/4Kq14Kq+4Kqy4KqvIOCqnOCrh+CqquCrgeCqsDXgqpfgq43gqrDgqr7gqq4g4Kq44Kqa4Kq/4Kq14Kq+4Kqy4KqvIOCqnOCrh+CqquCrgeCqsDXgqpfgq43gqrDgqr7gqq4g4Kq44Kqa4Kq/4Kq14Kq+4Kqy4KqvIOCqnOCrh+CqquCrgeCqsGQCAw9kFgJmDxUFHmFzc2V0cy9pbWFnZXMvYmxvZy1wb3N0L3AzLmpwZzXgqoXgqqjgq4Hgqqrgqq4g4Kqq4KuN4Kqw4Kq+4Kql4Kqu4Kq/4KqVIOCqtuCqvuCqs+CqvjXgqoXgqqjgq4Hgqqrgqq4g4Kqq4KuN4Kqw4Kq+4Kql4Kqu4Kq/4KqVIOCqtuCqvuCqs+Cqvirgqrjgq43gqqXgqr7gqqrgqqjgqr4g4KqILuCquC7gq6fgq6/gq6bgq6uRFuCquOCrjOCqpeCrgCDgqqrgqrngq4fgqrLgqr7gqoIg4Kqc4KuH4Kqq4KuB4KqwIOCqheCqqOCrgeCqquCqriDgqqrgq43gqrDgqr7gqqXgqq7gqr/gqpUg4Kq24Kq+4Kqz4Kq+IOCqiC7gqrgu4Kun4Kuv4Kum4Kur4Kqu4Kq+4KqCIOCqluCqvuCqqOCql+CrgCDgqrbgqr7gqrPgqr4g4Kqk4Kqw4KuA4KqV4KuHIOCql+CqvuCqruCqqOCqviDgqrDgqr7gqq7gqpzgq4Ag4Kqu4KqC4Kqm4Kq/4Kqw4Kqu4Kq+4KqCIOCqtuCqsOCrgSDgqqXgqocg4Kq54Kqk4KuALiDgqqTgq43gqq/gqr7gqrDgqqzgqr7gqqYg4KqILuCquC7gq6fgq6/gq6fgq6fgqq7gqr7gqoIg4KqW4Kq+4Kqo4KqX4KuAIOCqtuCqvuCqs+CqvuCqruCqvuCqguCqpeCrgCDgqrjgqrDgqpXgqr7gqrDgq4Ag4Kq24Kq+4Kqz4Kq+4Kqu4Kq+4KqCIOCqruCqvuCqqOCrjeCqr+CqpOCqviDgqq7gqrPgq4AuIOCqiC7gqrgu4Kun4Kuv4Kuq4Kuo4Kqu4Kq+4KqCIOCql+CrjeCqsOCqvuCqruCqnOCqqOCri+CqjyDgqpzgqq7gq4Dgqqgg4KqW4Kqw4KuA4Kqm4KuA4Kqo4KuHIOCqtuCqvuCqs+CqvuCqqOCqviDgqprgqr7gqrAg4KqT4Kqw4Kqh4Kq+IOCqrOCqvuCqguCqp+CqteCqvuCqqOCrgCDgqrbgqrDgq4LgqobgqqQg4KqV4Kqw4KuALiDgqogu4Kq4LuCrp+Crr+Crq+CrpuCqruCqvuCqgiDgqprgqr7gqrAg4KqT4Kqw4Kqh4Kq+4Kqo4KuB4KqCIOCqrOCqvuCqguCqp+CqleCqvuCqriDgqqXgqq/gq4HgqoIuIOCqpOCrjeCqr+CqvuCqsOCqrOCqvuCqpiDgqogu4Kq4LuCrp+Crr+Crq+CrqeCqruCqvuCqgiDgqpXgq4Pgqrfgqr8g4KqJ4Kqm4KuN4Kqv4KuL4KqXIOCqtuCqsOCrgSDgqqXgqqTgqr7gqoIg4KqGIOCqtuCqvuCqs+CqviDgqpXgq4Pgqrfgqr8g4Kqs4KuB4Kqo4Kq/4Kqv4Kq+4Kqm4KuAIOCqtuCqvuCqs+CqviDgqqzgqqjgq4AuIOCqtuCqvuCqs+CqviDgqqrgqr7gqrjgq4cg4KusIOCqj+CqleCqsCDgqpzgq4fgqrXgq4Ag4Kqc4Kqu4KuA4KqoIOCqueCri+CqteCqvuCqpeCrgCDgqpbgq4fgqqTgq4Ag4Kql4Kq14Kq+IOCqsuCqvuCql+CrgC4g4Kqk4KuN4Kqv4Kq+4Kqw4Kqs4Kq+4KqmIOCqnOCrh+CqquCrgeCqsCDgqpfgqr7gqq7gqqjgqr4g4Kq14Kq+4Kqk4Kqo4KuAIOCqheCqqOCrhyDgqongqqTgq43gqrjgqr7gqrngq4Ag4KqP4Kq14Kq+IOCqtuCrjeCqsOCrgCDgqqTgq43gqrDgqr/gqpXgqq7gqq3gqr7gqogg4Kqq4KuB4KqC4Kqc4Kq+4Kqt4Kq+4KqIIOCqquCqn+Crh+CqsuCrhyDgqogu4Kq4LuCrp+Crr+CrrOCrrOCqruCqvuCqgiDgqobgqprgqr7gqrDgq43gqq/gqrbgq43gqrDgq4Dgqqjgq4Ag4Kqn4KuB4Kqw4Kq+IOCquOCqguCqreCqvuCqs+CrgC4g4Kqk4KuH4Kqu4Kqo4KuAIOCqhuCql+CqteCrgCDgqqbgq4DgqrDgq43gqqfgqqbgq43gqrDgqrfgq43gqp/gqr8g4KqF4Kqo4KuHIOCqleCri+CqoOCqvuCquOCrguCqnSDgqqTgqqXgqr4g4Kqo4Kq/4Kq34KuN4Kqg4Kq+4Kql4KuAIOCqtuCqvuCqs+CqvuCqqOCrgCDgqq3gq4zgqqTgqr/gqpUg4Kq44KuB4Kq14Kq/4Kqn4Kq+4KqTIOCql+CqvuCqruCqqOCqviDgqqbgqr7gqqTgqr7gqrbgq43gqrDgq4DgqpMg4Kqk4Kqw4Kqr4Kql4KuAIOCqquCrjeCqsOCqvuCqquCrjeCqpCDgqqXgqoguIOCqiC7gqrgu4Kun4Kuv4Kut4Kum4Kqu4Kq+4KqCIOCqrOCrhyDgqqjgqrXgqr4g4KqT4Kqw4Kqh4Kq+IOCqrOCqvuCqguCqp+CqteCqvuCqruCqvuCqgiDgqobgqrXgq43gqq/gqr4uIOCqiC7gqrgu4Kun4Kuv4Kuu4Kuo4Kqu4Kq+4KqCIOCqtuCqvuCqs+CqvuCqqOCrhyDgqqrgqpfgqr7gqrAg4KqV4KuH4Kqo4KuN4Kqm4KuN4KqwIOCqtuCqvuCqs+CqviDgqqzgqqjgqr7gqrXgqrXgqr7gqq7gqr7gqoIg4KqG4Kq14KuALiDgqogu4Kq4LuCrp+Crr+CrruCrq+CqruCqvuCqgiDgqo/gqpUg4Kqo4Kq14KuA4KqoIOCqk+CqsOCqoeCriyDgqqzgqr7gqoLgqqfgqrXgqr7gqq7gqr7gqoIg4KqG4Kq14KuN4Kqv4KuLLiDgqogu4Kq4LuCrqOCrpuCrpuCrqOCqruCqvuCqgiDgqoXgqqjgq4Hgqqrgqq4g4Kq24Kq+4Kqz4Kq+IOCqueCqsOCrgOCqq+CqvuCqiOCqruCqvuCqgiDgqq3gqr7gqpcg4Kqy4KqHIOCqnOCrh+CqquCrgeCqsCDgqoXgqqjgq4Hgqqrgqq4g4Kqq4KuN4Kqw4Kq+4Kql4Kqu4Kq/4KqVIOCqtuCqvuCqs+CqviDgqqzgqqjgq4AuIOCqiC7gqrgu4Kuo4Kum4Kun4Kuo4Kqu4Kq+4KqCIOCql+CrjeCqsOCqvuCqruCqnOCqqOCri+CqjyDgqoXgqqbgqq7gq43gqq8g4KqJ4Kqk4KuN4Kq44Kq+4Kq54Kql4KuALOCqtuCqleCrjeCqpOCqvyDgqpXgqrDgqqTgqr7gqoIg4Kqq4KqjIOCqteCqv+CqtuCrh+CqtyDgqobgqrDgq43gqqXgqr/gqpUg4Kq44Kq54Kqv4KuL4KqXIOCqhuCqquCrgCDgqq3gqrXgq43gqq8g4Kq24Kq+4Kqz4Kq+IOCqtuCqpOCqvuCqrOCrjeCqpuCrgCDgqq7gqrngq4vgqqTgq43gqrjgqrXgqqjgq4Ag4KqJ4Kqc4Kq14Kqj4KuAIOCqleCqsOCrgC4g4KqG4Kqc4KuHIOCqtuCqvuCqs+CqviDgqqTgqr7gqrLgq4HgqpXgqr7gqq7gqr7gqoIg4KqP4KqVIOCqhuCql+CqteCrgCDgqqjgqr7gqq7gqqjgqr4g4Kqn4Kqw4Kq+4Kq14KuHIOCqm+Crhy4g4KqG4Kqc4KuHIOCqtuCqvuCqs+CqvuCqjyDgqrjgqrDgq43gqrXgqr7gqoLgqpfgq4Ag4Kq14Kq/4KqV4Kq+4Kq44Kqo4KuAIOCqqOCrh+CqriDgqrjgqr7gqqXgq4cg4KqX4Kqk4Kq/IOCqleCqsOCrgCDgqrDgqrngq4Ag4Kqb4KuHLiDgqrbgqr7gqrPgqr7gqq7gqr7gqoIg4Kqk4Kqu4Kq+4KquIOCquOCql+CqteCqoeCriyDgqongqqrgqrLgqqzgq43gqqcg4Kqb4KuHLiDgqrjgqr7gqrDgq4Ag4KqV4Kqu4KuN4Kqq4KuN4Kqv4KuB4Kqf4KqwIOCqsuCrh+CqrCDgqqrgqqMg4Kqb4KuHLiBkAgQPZBYCZg8VBR5hc3NldHMvaW1hZ2VzL2Jsb2ctcG9zdC9wMS5qcGc74KqJ4Kqu4Kq/4Kqv4Kq+IOCqruCqvuCqpOCqvuCqnOCrgOCqqOCrgeCqgiDgqq7gqoLgqqbgqr/gqrA74KqJ4Kqu4Kq/4Kqv4Kq+IOCqruCqvuCqpOCqvuCqnOCrgOCqqOCrgeCqgiDgqq7gqoLgqqbgqr/gqrAs4Kq44KuN4Kql4Kq+4Kqq4Kqo4Kq+IOCquOCqqOCrhyDgq6jgq6bgq6bgq6fxCeCqnOCrh+CqquCrgeCqsCDgqpfgqr7gqq7gqqjgq4Ag4Kqu4KuL4Kqf4Kq+4Kqt4Kq+4KqX4Kqo4KuAIOCqteCquOCrjeCqpOCrgCDgqqrgqr7gqp/gq4Dgqqbgqr7gqrAg4Kqt4Kq+4KqI4KqT4Kqo4KuAIOCqm+Crhy4g4Kqq4Kq+4Kqf4KuA4Kqm4Kq+4Kqw4KuL4Kqo4KuAIOCqleCrgeCqs+CqpuCrh+CqteCrgCDgqrbgq43gqrDgq4Ag4KqJ4Kqu4Kq/4Kqv4Kq+IOCqruCqvuCqpOCqvuCqnOCrgCDgqrngq4vgqrXgqr7gqqXgq4Ag4KqX4Kq+4Kqu4Kqu4Kq+4KqCIOCqreCqteCrjeCqryDgqongqq7gqr/gqq/gqr4g4Kqu4KqC4Kqm4Kq/4KqwIOCqrOCqvuCqguCqp+CqteCqvuCqqOCrgeCqgiDgqqjgqpXgq43gqpXgq4Ag4KqV4Kqw4Kq14Kq+4Kqu4Kq+4KqCIOCqhuCqteCrjeCqr+CrgeCqgi4g4Kq44Kqo4KuHOiDgq6jgq6bgq6bgq6cg4Kqu4Kq+4KqCIOCqiuCqguCqneCqviDgqq7gq4HgqpXgqr7gqq7gq4cg4KqG4Kq14KuH4KqyIOCqreCqteCrjeCqr+CqvuCqpOCqv+CqreCqteCrjeCqryDgqongqq7gqr/gqq/gqr4g4Kqu4Kq+4Kqk4Kq+4Kqc4KuA4Kqo4Kq+IOCqruCrgeCqluCrjeCqryDgqrjgq43gqqXgqr7gqqjgqpXgqq7gqr7gqoLgqqXgq4Ag4Kqc4KuN4Kqv4KuL4KqkIOCqsuCqvuCqteCrgCDgqq7gqoLgqqbgqr/gqrDgqqjgq4Ag4Kq44KuN4Kql4Kq+4Kqq4Kqo4Kq+IOCqleCqsOCqteCqvuCqruCqvuCqgiDgqobgqrXgq4AuIOCqteCquOCqguCqpOCqquCqguCqmuCqruCrgOCqqOCriyDgqqrgqr7gqp/gq4vgqqTgq43gqrjgqrUg4Kqn4Kq+4Kqu4Kqn4KuB4Kqu4Kql4KuAIOCql+CrjeCqsOCqvuCqruCqsuCri+CqleCriyDgqq3gq4fgqpfgqr4g4Kqu4Kqz4KuA4Kqo4KuHIOCqiuCqnOCqteCrhyDgqpvgq4cuIOCqtuCrjeCqsOCrgCDgqongqq7gqr/gqq/gqr4g4Kqu4Kq+4Kqk4Kq+4Kqc4KuA4Kqo4KuHIOCqteCquOCqguCqpOCqquCqguCqmuCqruCrgCDgqoXgqqjgq4cg4Kqm4Kq/4Kq14Kq+4Kqz4KuA4Kqo4Kq+IOCqpuCqv+CqteCquOCrhyDgq6vgq6wg4Kqt4KuL4KqXIOCqheCqqOCrhyDgqoXgqqjgq43gqqjgqpXgq4Lgqp8g4KqF4Kqw4KuN4Kqq4KqjIOCqleCqsOCqteCqvuCqruCqvuCqgiDgqobgqrXgq4cg4Kqb4KuHLiDgqqbgqrAg4Kq24KuN4Kqw4Kq+4Kq14KqjIOCqruCqvuCquOCqruCqvuCqgiDgqq3gqpzgqqgsIOCquOCqpOCrjeCquOCqguCqlyDgqoXgqqjgq4cg4KqV4Kql4Kq+4Kqo4KuB4KqCIOCqhuCqr+Cri+CqnOCqqCDgqpXgqrDgqrXgqr7gqq7gqr7gqoIg4KqG4Kq14KuHIOCqm+Crhy4gZAIFD2QWAmYPFQUeYXNzZXRzL2ltYWdlcy9ibG9nLXBvc3QvcDIuanBnQeCqruCqueCqvuCqleCqvuCqs+CrgCDgqq7gqr7gqqTgqr7gqpzgq4Dgqqjgq4HgqoIg4Kqu4KqC4Kqm4Kq/4KqwQeCqruCqueCqvuCqleCqvuCqs+CrgCDgqq7gqr7gqqTgqr7gqpzgq4Dgqqjgq4HgqoIg4Kqu4KqC4Kqm4Kq/4KqwLOCquOCrjeCqpeCqvuCqquCqqOCqviDgqrjgqqjgq4cg4Kuo4Kum4Kum4Kun7QPgqq7gqrngqr7gqpXgqr7gqrPgq4Ag4Kqu4Kq+4Kqk4Kq+4Kqc4KuA4Kqo4Kq+IOCqruCqguCqpuCqv+CqsOCqqOCrgCDgqrjgq43gqqXgqr7gqqrgqqjgqr4g4Kqu4KuC4KqzIOCqhuCql+CqsuCri+CqoSDgqpfgqr7gqq7gqqXgq4Ag4Kqm4KuA4Kq14KuLIOCqsuCqvuCqteCrgOCqqOCrhywg4Kqk4KuL4Kqw4KqjIOCqrOCqvuCqguCqp+CrgOCqqOCrhyDgqpXgqrDgqrXgqr7gqq7gqr7gqoIg4KqG4Kq14KuAIOCqueCqpOCrgC4g4Kqc4KuH4Kqo4KuHIOCqquCrgOCqguCqquCqs+CrgCDgqq7gqr7gqqTgqr7gqpzgq4Dgqqjgq4HgqoIg4Kqu4KqC4Kqm4Kq/4KqwIOCqquCqoyDgqpXgqrngq4cg4Kqb4KuHLiDgqoYg4Kqu4KqC4Kqm4Kq/4KqwIOCqpuCqleCrjeCqt+Cqv+CqoyDgqqbgqr/gqrbgqr7gqq7gqr7gqoIg4KqG4Kq14KuH4KqyIOCqm+Crhy4g4Kqa4KuI4Kqk4KuN4KqwIOCqqOCrjOCqruCqqOCriyDgqq7gq4fgqrPgq4sg4Kqt4Kqw4Kq+4KqvIOCqm+Crhy4gZAIGD2QWAmYPFQUfYXNzZXRzL2ltYWdlcy9ibG9nLXBvc3QvcDEyLmpwZy/gqrDgqr7gqq7gqpzgq4Ag4Kqu4KqC4Kqm4Kq/4KqwIOCqnOCrh+CqquCrgeCqsC/gqrDgqr7gqq7gqpzgq4Ag4Kqu4KqC4Kqm4Kq/4KqwIOCqnOCrh+CqquCrgeCqsCvgqrjgq43gqqXgqr7gqqrgqqjgqr4g4KqILuCquC4g4Kun4Kuv4Kut4Kum/wbgqrDgqr7gqq7gqpzgq4Ag4Kqu4KqC4Kqm4Kq/4Kqw4Kqo4KuAIOCquOCrjeCqpeCqvuCqquCqqOCqviDgqrLgqpfgqq3gqpcg4Kun4Kuo4KurIOCqteCqsOCrjeCqtyDgqqrgqrngq4fgqrLgqr7gqoIg4Kql4KqIIOCqueCri+CqteCqvuCqqOCrgeCqgiDgqq7gqr7gqqjgqrXgqr7gqq7gqr7gqoIg4KqG4Kq14KuHIOCqm+Crhy4g4Kqk4KuN4Kqv4Kq+4Kqw4Kqs4Kq+4KqmIOCqiC7gqrguIOCrp+Crr+CrreCrpuCqruCqvuCqgiDgqqTgq4fgqqjgq4sg4Kqc4KuA4Kqw4KuN4Kqj4KuL4Kqn4KuN4Kqn4Kq+4KqwIOCqleCqsOCqteCqvuCqruCqvuCqgiDgqobgqrXgq43gqq/gq4suIOCqhiDgqq7gqoLgqqbgqr/gqrDgqq7gqr7gqoIg4Kqw4Kq+4Kqu4Kqo4Kq14Kqu4KuAICzgqpzgqqjgq43gqq7gqr7gqrfgq43gqp/gqq7gq4Ag4KqF4Kqo4KuHIOCqpuCqv+CqteCqvuCqs+CrgOCqqOCqviDgqongqqTgq43gqrjgqrXgq4sg4Kqn4Kq+4Kqu4Kqn4KuC4Kqu4Kql4KuA4KqJ4Kqc4Kq14Kq14Kq+4Kqu4Kq+4KqCIOCqhuCqteCrhyDgqpvgq4cuIOCqteCqs+CrgCwg4Kqw4Kq+4Kqu4Kqo4Kq14Kqu4KuA4Kqo4Kq+IOCqpuCqv+CqteCquOCrhyDgqoXgqrngq4DgqoIg4Kqu4KuH4Kqz4KuLIOCqreCqsOCqvuCqryDgqpvgq4cuIOCqreCqvuCqpuCqsOCqteCqviDgqrjgq4HgqqYg4KqF4KqX4Kq/4Kqv4Kq+4Kqw4Kq44Kqo4Kq+IOCqtuCrgeCqreCqpuCqv+CqqOCrhyDgqq7gqoLgqqbgqr/gqrDgqq7gqr7gqoLgqqXgq4Ag4Kqt4KqX4Kq14Kq+4KqoIOCqtuCrjeCqsOCrgCDgqrLgqr7gqrLgqpzgq4Ag4Kqu4Kq54Kq+4Kqw4Kq+4Kqc4Kqo4KuAIOCqtuCri+CqreCqvuCqr+CqvuCqpOCrjeCqsOCqviDgqqrgqqMg4KqV4Kq+4Kqi4Kq14Kq+4Kqu4Kq+4KqCIOCqhuCqteCrhyDgqpvgq4cuZAIHD2QWAmYPFQUeYXNzZXRzL2ltYWdlcy9ibG9nLXBvc3QvcDcuanBnO+CqpuCrguCqp+Crh+CqtuCrjeCqteCqsCDgqq7gqrngqr7gqqbgq4fgqrUg4Kqu4KqC4Kqm4Kq/4KqwO+CqpuCrguCqp+Crh+CqtuCrjeCqteCqsCDgqq7gqrngqr7gqqbgq4fgqrUg4Kqu4KqC4Kqm4Kq/4KqwLOCquOCrjeCqpeCqvuCqquCqqOCqviDgqrjgqqjgq4cg4Kun4Kuv4Kuu4KurpgLgqoYg4Kqu4KqC4Kqm4Kq/4Kqw4Kqo4KuAIOCquOCrjeCqpeCqvuCqquCqqOCqviDgqrLgqpfgqq3gqpcg4KqX4Kq+4Kqu4Kqo4Kq+IOCqteCquOCqteCqvuCqn+CqqOCqviDgqrjgqq7gqq/gq4cg4Kqs4Kq54Kq+4Kqw4KqX4Kq+4Kqu4Kql4KuAIOCqhuCqteCrh+CqsuCqviDgqrDgqr7gqqfgq4fgqqrgq4HgqrDgq4Ag4Kqs4Kq+4Kq14Kq+4Kqc4KuAIOCqpuCrjeCqteCqvuCqsOCqviDgqpXgqrDgqrXgqr7gqq7gqr7gqoIg4KqG4Kq14KuAIOCqueCri+CqteCqvuCqqOCrgeCqgiDgqq7gqqjgqr7gqq8g4Kqb4KuHLiBkAggPZBYCZg8VBR5hc3NldHMvaW1hZ2VzL2Jsb2ctcG9zdC9wNC5qcGc14Kqq4KuA4Kq14Kq+4Kqo4Kq+IOCqquCqvuCqo+CrgOCqqOCrgCDgqp/gqr7gqoLgqpXgq4A14Kqq4KuA4Kq14Kq+4Kqo4Kq+IOCqquCqvuCqo+CrgOCqqOCrgCDgqp/gqr7gqoLgqpXgq4As4Kq44KuN4Kql4Kq+4Kqq4Kqo4Kq+IOCquOCqqOCrhyDgq6fgq6/gq6/gq6v/BeCqquCrgOCqteCqvuCqqOCqviDgqqrgqr7gqqPgq4Dgqqjgq4Ag4Kqf4Kq+4KqC4KqV4KuA4Kqo4KuAIOCquOCrjeCqpeCqvuCqquCqqOCqviDgqrjgqqjgq4c64Kun4Kuv4Kuv4Kur4Kqu4Kq+4KqCIOCquOCqsOCqleCqvuCqsOCqtuCrjeCqsOCrgOCqqOCqviDgqrjgqrngqq/gq4vgqpfgqqXgq4Ag4Kqs4Kqo4Kq+4Kq14Kq14Kq+4Kqu4Kq+4KqCIOCqhuCqteCrgCDgqrngqqTgq4AuIOCqhiDgqp/gqr7gqoLgqpXgq4Dgqqjgq4Ag4KqV4KuN4Kq34Kqu4Kqk4Kq+IOCrp+CrpuCrpuCrpuCrpuCrpuCrpiDgqrLgq4Dgqp/gqrDgqqjgq4Ag4Kqb4KuHLiDgqoYg4Kqf4Kq+4KqC4KqV4KuAIOCqrOCqqOCqvuCqteCqteCqvuCqqOCriyDgqq7gq4Hgqpbgq43gqq8g4KqJ4Kqm4KuN4Kqm4KuH4Kq2IOCqpuCrgeCqt+CrjeCqleCqvuCqs+Cql+CrjeCqsOCquOCrjeCqpCDgqrjgqq7gqq/gqpfgqr7gqrPgqr7gqqjgqr7gqoIs4Kqq4Kq+4Kqj4KuA4Kqo4KuLIOCqn+CrjeCqr+CrgeCqrOCqteCrh+CqsiDgqqzgqpfgqqHgq43gqq/gq4sg4Kq54KuL4KqvLOCqteCrgOCqnOCqs+CrgOCqqOCrgCDgqpXgq43gqrfgqqTgqr8g4Kq44Kqw4KuN4Kqc4Kq+4KqIIOCqueCri+CqryDgqqTgq4fgqrXgqr4g4Kq44Kqu4Kqv4KuHIOCqruCqvuCqqOCqteCrgOCqkyDgqoXgqqjgq4cg4Kqq4Kq24KuB4KqT4Kqo4KuHIOCqquCqvuCqo+CrgOCqqOCrgCDgqpzgqrDgq4LgqrDgqr/gqq/gqr7gqqTgq4sg4Kqq4KuC4Kqw4KuAIOCqquCqvuCqoeCqteCqvuCqqOCriyDgqpvgq4cuZAIJD2QWAmYPFQUfYXNzZXRzL2ltYWdlcy9ibG9nLXBvc3QvcDExLmpwZ3Lgqq7gqrngq4fgqrjgqr7gqqPgqr4g4Kqh4KuA4Kq44KuN4Kqf4KuN4Kqw4KuA4KqV4KqfIOCquOCrh+CqqOCrjeCqn+CrjeCqsOCqsiDgqpXgq4suIOCqky4g4Kqs4KuH4Kqo4KuN4KqVIOCqsuCrgC5y4Kqu4Kq54KuH4Kq44Kq+4Kqj4Kq+IOCqoeCrgOCquOCrjeCqn+CrjeCqsOCrgOCqleCqnyDgqrjgq4fgqqjgq43gqp/gq43gqrDgqrIg4KqV4KuLLiDgqpMuIOCqrOCrh+CqqOCrjeCqlSDgqrLgq4AuLOCquOCrjeCqpeCqvuCqquCqqOCqviDgqrjgqqjgq4cg4Kun4Kuv4Kuu4Kumhwbgqpfgq43gqrDgqr7gqq7gqpzgqqjgq4vgqqjgq4cg4KqY4KuH4KqwIOCqrOCrh+CqoOCqvuCqgiDgqqjgqr7gqqPgqr7gqoLgqpXgq4Dgqq8g4Kqy4KuH4Kq14KqhLeCqpuCrh+CqteCqoeCqqOCrgCDgqrjgqrDgqrPgqqTgqr4g4Kqw4Kq54KuHIOCqpOCrhyDgqrngq4fgqqTgq4HgqrjgqrAg4Kqk4Kq+4Kqw4KuA4KqWOiDgq6cv4KunL+Crp+Crr+CrruCrpiDgqqjgqr4g4Kqw4KuL4KqcIOCquOCqpuCqsCDgqqzgq4fgqoLgqpXgqqjgq4Ag4Kq44KuN4Kql4Kq+4Kqq4Kqo4Kq+IOCqpeCqiC4g4KqGIOCqrOCrh+CqguCqleCqruCqvuCqgiDgq6ngq6ngq6vgq6og4KqW4Kq+4Kqk4KuH4Kqm4Kq+4Kqw4KuLIOCqheCqqOCrhyDgq6rgq6vgq6Yg4Kqy4KuL4KqV4Kqw4KuN4Kq4IOCqluCqvuCqpOCrh+CqpuCqvuCqsOCriyDgqpvgq4cuIOCqrOCrh+CqguCqleCqqOCrgeCqgiDgqrDgq4vgqpzgqqjgq4HgqoIg4Kqf4Kqw4KuN4Kqo4KqT4Kq14KqwIOCqheCqguCqpuCqvuCqnOCrgOCqpCDgq6rgq6Yg4Kqy4Kq+4KqWIOCqsOCrguCqquCqv+Cqr+CqviDgqpzgq4fgqp/gqrLgq4HgqoIg4Kqb4KuHLiDgqqzgq4fgqoLgqpXgqq7gqr7gqoIg4KqV4Kq+4Kqv4Kqu4KuAIOCqp+Cri+CqsOCqo+CrhyDgqo/gqpUg4KqV4Kqw4KuN4Kqu4Kqa4Kq+4Kqw4KuAIOCqq+CqsOCqnCDgqqzgqpzgqr7gqrXgq4cg4Kqb4KuHIOCqpOCqpeCqviDgqo/gqpUg4KqV4Kqw4KuN4Kqu4Kqa4Kq+4Kqw4KuAIOCqueCqguCql+CqvuCqruCrgCDgqrjgq4fgqrXgqr4g4KqG4Kqq4KuHIOCqm+Crhy4gZAIKD2QWAmYPFQUeYXNzZXRzL2ltYWdlcy9ibG9nLXBvc3QvcDYuanBncOCqquCrjeCqsOCql+CqpOCqvyDgqq/gq4HgqrXgqpUg4KqV4KuLLuCqk+CqquCqsOCrh+Cqn+CrgOCqtSDgqpXgq43gqrDgq4fgqqHgq4Dgqp8g4Kq44KuL4Kq44Kq+4Kqv4Kqf4KuAIOCqsuCrgC5w4Kqq4KuN4Kqw4KqX4Kqk4Kq/IOCqr+CrgeCqteCqlSDgqpXgq4su4KqT4Kqq4Kqw4KuH4Kqf4KuA4Kq1IOCqleCrjeCqsOCrh+CqoeCrgOCqnyDgqrjgq4vgqrjgqr7gqq/gqp/gq4Ag4Kqy4KuALizgqrjgq43gqqXgqr7gqqrgqqjgqr4g4Kq44Kqo4KuHIOCrp+Crr+CrruCrq6sG4Kqq4KuN4Kqw4KqX4Kqk4Kq/IOCqr+CrgeCqteCqlSDgqq7gqoLgqqHgqrPgq4cg4Kqq4KuN4Kqw4KqX4Kqk4Kq/IOCqr+CrgeCqteCqlSDgqpXgq4su4KqT4Kqq4Kqw4KuH4Kqf4KuA4Kq1IOCqleCrjeCqsOCrh+CqoeCrgOCqnyDgqrjgq4vgqrjgqr7gqq/gqp/gq4Ag4Kqy4Kq/4Kqu4Kq/4Kqf4KuH4Kqh4Kqo4KuAIOCquOCrjeCqpeCqvuCqquCqqOCqviDgqqTgqr4u4Kun4KupL+Crp+Crpy/gq6fgq6/gq67gq6vgqqjgqr4g4Kqw4KuL4KqcIOCqleCqsOCrgCDgqrngqqTgq4AuIOCql+CrjeCqsOCqvuCqruCqnOCqqOCri+CqruCqvuCqgiDgqqzgqprgqqTgqqjgq4Ag4Kq14Kq/4Kq24KuH4Kq3IOCqreCqvuCqteCqqOCqviDgqpXgq4fgqrPgqrXgqr7gqq8s4KqV4Kqw4KuH4Kqy4KuAIOCqrOCqmuCqpOCqqOCrgCDgqrjgqrLgqr7gqq7gqqTgq4Ag4Kq44Kq+4Kql4KuHIOCqr+Cri+Cql+CrjeCqryDgqrXgq43gqq/gqr7gqpwg4Kqu4Kqz4KuHIOCqpOCqpeCqviDgqpzgqrDgq4LgqrDgqr/gqq/gqr7gqqQg4Kqu4KqC4Kqm4KuL4Kqo4KuHIOCqteCrjeCqr+CqvuCqnOCqrOCrgCDgqqbgqrDgq4cg4Kqn4Kq/4Kqw4Kq+4KqjIOCqruCqs+CrgCDgqrDgqrngq4cg4Kqk4KuHIOCqieCqpuCrjeCqpuCrh+CqtuCqpeCrgCDgqrjgq43gqqXgqr7gqqrgqqjgqr4g4KqV4Kqw4Kq14Kq+4Kqu4Kq+4KqCIOCqhuCqteCrh+CqsuCrgC4g4Kun4Kus4Kup4KutICDgqrjgqq3gqr7gqrjgqqbgq4sg4Kqb4KuHLiDgqqTgq43gqrDgqqMg4KqV4Kqw4KuN4Kqu4Kqa4Kq+4Kqw4KuA4KqTIOCqq+CqsOCqnCDgqqzgqpzgqr7gqrXgq4cg4Kqb4KuHLmQCCw9kFgJmDxUFHmFzc2V0cy9pbWFnZXMvYmxvZy1wb3N0L3A5LmpwZ0Lgqpzgq4fgqqrgq4HgqrAg4Kqm4KuC4KqnIOCqieCqpOCrjeCqquCqvuCqpuCqlSDgqrgu4Kqu4KqCLuCqsuCrgC5C4Kqc4KuH4Kqq4KuB4KqwIOCqpuCrguCqpyDgqongqqTgq43gqqrgqr7gqqbgqpUg4Kq4LuCqruCqgi7gqrLgq4AuLOCquOCrjeCqpeCqvuCqquCqqOCqviDgqrjgqqjgq4cg4Kun4Kuv4Kut4Kuu0Ajgqpzgq4fgqqrgq4HgqrAg4Kqm4KuC4KqnIOCqieCqpOCrjeCqquCqvuCqpuCqlSDgqrgu4Kqu4KqCLuCqsuCrgC4g4Kqo4KuAIOCquOCrjeCqpeCqvuCqquCqqOCqviDgqqTgqr46IOCrqOCrpy3gq6fgq6gt4Kun4Kuv4Kut4KuuIOCqqOCqviDgqrDgq4vgqpwg4KqV4Kqw4Kq14Kq+4Kqu4Kq+4KqCIOCqhuCqteCrgCDgqrngqqTgq4AuIOCql+CqvuCqruCqqOCqviDgqrLgq4vgqpXgq4vgqqjgq4sg4Kqu4KuB4KqW4KuN4KqvIOCqteCrjeCqr+CqteCquOCqvuCqryDgqqrgqrbgq4Hgqqrgqr7gqrLgqqgg4Kq54KuL4Kq14Kq+4Kql4KuAIOCqpuCrguCqp+CqqOCqviDgqqrgq4vgqrfgqqPgqpXgq43gqrfgqq4g4Kqt4Kq+4Kq1IOCqruCqs+CrgCDgqrDgqrngq4cg4Kqk4KuHIOCqieCqpuCrjeCqpuCrh+CqtuCqpeCrgCDgqqHgq4fgqrDgq4Dgqqjgq4Ag4Kq44KuN4Kql4Kq+4Kqq4Kqo4Kq+IOCqleCqsOCqteCqvuCqruCqvuCqgiDgqobgqrXgq4Ag4Kq54Kqk4KuALiDgqoYg4Kqh4KuH4Kqw4KuA4Kqu4Kq+4KqCIOCrrCjgqpspIOCqleCqsOCrjeCqruCqmuCqvuCqsOCrgOCqkyDgqqvgqrDgqpwg4Kqs4Kqc4Kq+4Kq14KuHIOCqm+Crhy4g4Kqh4KuH4Kqw4KuA4Kqu4Kq+4KqCIOCqpuCrguCqp+CqqOCqviDgqq7gqrbgq4Dgqqjgq4vgqqXgq4Ag4Kqm4KuC4KqnIOCqruCqvuCqquCqqCDgqqTgqqXgqr4g4Kqr4KuH4KqfIOCqruCqtuCrgOCqqOCqpeCrgCDgqqbgq4Lgqqfgqqjgq4Ag4KqV4KuN4Kq34Kqu4Kqk4Kq+IOCqruCqquCqvuCqryDgqpvgq4cuIOCqoeCrh+CqsOCrgOCqruCqvuCqgiDgqqbgq4Lgqqfgqqjgqr4g4Kq44KqC4KqX4KuN4Kqw4Kq5IOCqruCqvuCqn+CrhyDgqo/gqrDgqpXgqoLgqqHgq4DgqrbgqqjgqrAg4Kqf4Kq+4KqC4KqV4Kq+4Kqo4KuAIOCquOCql+CqteCqoSDgqpvgq4cuIOCqueCqvuCqsuCqruCqvuCqgiDgqqHgq4fgqrDgq4Dgqq7gqr7gqoIg4KqV4KuB4KqyIOCrqOCrq+CrpiDgqrjgqq3gqr7gqrjgqqbgq4sg4Kqb4KuHLiDgqqHgq4fgqrDgq4Dgqq7gqr7gqoIg4Kqy4KqX4Kqt4KqXIOCquOCqteCqvuCqsC3gqrjgqr7gqoLgqpwg4Kun4Kur4KumIOCqleCrh+CqqCDgqqbgq4Lgqqcg4Kql4Kq+4KqvIOCqm+Crhy5kAgwPZBYCZg8VBR9hc3NldHMvaW1hZ2VzL2Jsb2ctcG9zdC9wMTMuanBnOOCqtuCrjeCqsOCrgCDgqpXgqr/gqrjgqr7gqqjgqqHgq4fgqrDgq4Ag4Kqc4KuH4Kqq4KuB4KqwOOCqtuCrjeCqsOCrgCDgqpXgqr/gqrjgqr7gqqjgqqHgq4fgqrDgq4Ag4Kqc4KuH4Kqq4KuB4KqwK+CquOCrjeCqpeCqvuCqquCqqOCqviDgqogu4Kq4LiDgq6fgq6/gq67gq62KBuCqtuCrjeCqsOCrgCDgqpXgqr/gqrjgqr7gqqgg4Kqh4KuH4Kqw4KuA4Kqo4KuAIOCquOCrjeCqpeCqvuCqquCqqOCqviDgqogu4Kq4LiDgq6fgq6/gq67gq60g4Kqo4Kq+IOCqsOCri+CqnCDgqpXgqrDgqrXgqr7gqq7gqr7gqoIg4KqG4Kq14KuAIOCqueCqpOCrgC4g4Kqm4KuC4Kqn4Kqo4Kq+IOCqquCri+Cqt+Cqo+CqleCrjeCqt+CqriDgqq3gqr7gqrUg4Kqu4Kqz4KuAIOCqsOCqueCrhyDgqqTgq4cg4Kq54KuH4Kqk4KuB4Kql4KuAIOCqoeCrh+CqsOCrgOCqqOCrgCDgqrjgq43gqqXgqr7gqqrgqqjgqr4g4KqV4Kqw4Kq14Kq+4Kqu4Kq+4KqCIOCqhuCqteCrgCDgqrngqqTgq4AuIOCqhiDgqqHgq4fgqrDgq4Dgqq7gqr7gqoIg4Kqa4Kq+4KqwIOCqleCqsOCrjeCqruCqmuCqvuCqsOCrgOCqkyDgqqvgqrDgqpwg4Kqs4Kqc4Kq+4Kq14KuHIOCqm+Crhy4g4Kqh4KuH4Kqw4KuA4Kqu4Kq+4KqCIOCqpuCrguCqpyDgqq7gqr7gqqrgqqgg4Kqu4Kq24KuA4KqoIOCqheCqqOCrhyDgqqvgq4fgqp8g4Kqu4Kq24KuA4Kqo4Kql4KuAIOCqpuCrguCqp+CqqOCrgCDgqpXgq43gqrfgqq7gqqTgqr4g4Kqu4Kqq4Kq+4KqvIOCqm+Crhy4g4Kqh4KuH4Kqw4KuA4Kqu4Kq+4KqCIOCqleCrgeCqsiDgq6ngq6jgq6Yg4Kq44Kqt4Kq+4Kq44Kqm4KuLIOCqm+Crhy4g4KqG4Kq24Kqw4KuHIOCquOCqteCqvuCqsC3gqrjgqr7gqoLgqpwg4KqV4KuB4KqyIOCrqOCrrOCrpuCrpiDgqrLgq4Dgqp/gqrAg4Kqm4KuC4KqnIOCqieCqpOCrjeCqquCqvuCqpuCqqCDgqqXgqr7gqq8g4Kqb4KuHLiBkAg0PZBYCZg8VBR9hc3NldHMvaW1hZ2VzL2Jsb2ctcG9zdC9wMTYuanBnOeCqqOCrjeCqr+CrgSDgqpXgqr/gqrjgqr7gqqgg4Kqh4KuH4Kqw4KuAIOCqnOCrh+CqquCrgeCqsDngqqjgq43gqq/gq4Eg4KqV4Kq/4Kq44Kq+4KqoIOCqoeCrh+CqsOCrgCDgqpzgq4fgqqrgq4HgqrA54Kqo4KuN4Kqv4KuBIOCqleCqv+CquOCqvuCqqCDgqqHgq4fgqrDgq4Ag4Kqc4KuH4Kqq4KuB4KqwAGQCDg9kFgJmDxUFH2Fzc2V0cy9pbWFnZXMvYmxvZy1wb3N0L3AxNy5qcGdD4Kqn4KuAIOCqquCrjeCqsOCql+CqpOCqvyDgqq/gq4HgqrXgqpUg4Kqu4KqC4Kqh4KqzIOCqnOCrh+CqquCrgeCqsEPgqqfgq4Ag4Kqq4KuN4Kqw4KqX4Kqk4Kq/IOCqr+CrgeCqteCqlSDgqq7gqoLgqqHgqrMg4Kqc4KuH4Kqq4KuB4KqwQ+Cqp+CrgCDgqqrgq43gqrDgqpfgqqTgqr8g4Kqv4KuB4Kq14KqVIOCqruCqguCqoeCqsyDgqpzgq4fgqqrgq4HgqrAAZAIPD2QWAmYPFQUfYXNzZXRzL2ltYWdlcy9ibG9nLXBvc3QvcDE4LmpwZ0Xgqqrgq4fgqp/gqr4g4KqG4Kqw4KuL4KqX4KuN4KqvIOCqleCrh+CqqOCrjeCqpuCrjeCqsCDgqpzgq4fgqqrgq4HgqrBF4Kqq4KuH4Kqf4Kq+IOCqhuCqsOCri+Cql+CrjeCqryDgqpXgq4fgqqjgq43gqqbgq43gqrAg4Kqc4KuH4Kqq4KuB4KqwReCqquCrh+Cqn+CqviDgqobgqrDgq4vgqpfgq43gqq8g4KqV4KuH4Kqo4KuN4Kqm4KuN4KqwIOCqnOCrh+CqquCrgeCqsABkAhAPZBYCZg8VBR9hc3NldHMvaW1hZ2VzL2Jsb2ctcG9zdC9wMTkuanBnIuCqquCqtuCrgSDgqqbgqrXgqr7gqpbgqr7gqqjgq4HgqoIi4Kqq4Kq24KuBIOCqpuCqteCqvuCqluCqvuCqqOCrgeCqgiLgqqrgqrbgq4Eg4Kqm4Kq14Kq+4KqW4Kq+4Kqo4KuB4KqCAGQCEQ9kFgJmDxUFH2Fzc2V0cy9pbWFnZXMvYmxvZy1wb3N0L3AyMC5qcGdO4Kqn4KuAIOCqnOCrh+CqquCrgeCqsCDgqrjgq4fgqrXgqr4g4Kq44Kq54KqV4Kq+4Kqw4KuAIOCqruCqguCqoeCqs+CrgCDgqrLgq4AuTuCqp+CrgCDgqpzgq4fgqqrgq4HgqrAg4Kq44KuH4Kq14Kq+IOCquOCqueCqleCqvuCqsOCrgCDgqq7gqoLgqqHgqrPgq4Ag4Kqy4KuALk7gqqfgq4Ag4Kqc4KuH4Kqq4KuB4KqwIOCquOCrh+CqteCqviDgqrjgqrngqpXgqr7gqrDgq4Ag4Kqu4KqC4Kqh4Kqz4KuAIOCqsuCrgC4AZAISD2QWAmYPFQUfYXNzZXRzL2ltYWdlcy9ibG9nLXBvc3QvcDIxLmpwZxjgqobgqoLgqpfgqqPgqrXgqr7gqqHgq4AY4KqG4KqC4KqX4Kqj4Kq14Kq+4Kqh4KuAGOCqhuCqguCql+Cqo+CqteCqvuCqoeCrgABkAhMPZBYCZg8VBR9hc3NldHMvaW1hZ2VzL2Jsb2ctcG9zdC9wMjIuanBnGOCqhuCqguCql+Cqo+CqteCqvuCqoeCrgBjgqobgqoLgqpfgqqPgqrXgqr7gqqHgq4AY4KqG4KqC4KqX4Kqj4Kq14Kq+4Kqh4KuAAGQCFA9kFgJmDxUFH2Fzc2V0cy9pbWFnZXMvYmxvZy1wb3N0L3AyMy5qcGcy4Kqw4Kq+4Kqu4KqV4Kqs4KuA4KqwIOCquOCqpOCrjeCquOCqguCqlyDgqrngq4vgqrIy4Kqw4Kq+4Kqu4KqV4Kqs4KuA4KqwIOCquOCqpOCrjeCquOCqguCqlyDgqrngq4vgqrIy4Kqw4Kq+4Kqu4KqV4Kqs4KuA4KqwIOCquOCqpOCrjeCquOCqguCqlyDgqrngq4vgqrIAZAIHD2QWBAIBDxYCHwECARYCZg9kFgJmDxUDtwHgqrXgqrDgq43gqrcgOiDgq6jgq6bgq6fgq64t4Kun4KuvIOCqruCqvuCqn+CrhyDgqpbgq4fgqqTgq4DgqrXgqr7gqqHgq4Dgqqjgq4Ag4Kq14Kq/4Kq14Kq/4KqnIOCqr+Cri+CqnOCqqOCqvuCqk+CqqOCrgCDgqpPgqqjgqrLgqr7gqofgqqgg4KqF4Kqw4Kqc4KuA4KqTIOCqruCqvuCqn+CrhyBDbGljayDgqpXgqrDgq4staHR0cDovL3d3dy5qZXB1cnBhbmNoYXlhdC5jb20vZ292cHJvamVjdC5hc3B4twHgqrXgqrDgq43gqrcgOiDgq6jgq6bgq6fgq64t4Kun4KuvIOCqruCqvuCqn+CrhyDgqpbgq4fgqqTgq4DgqrXgqr7gqqHgq4Dgqqjgq4Ag4Kq14Kq/4Kq14Kq/4KqnIOCqr+Cri+CqnOCqqOCqvuCqk+CqqOCrgCDgqpPgqqjgqrLgqr7gqofgqqgg4KqF4Kqw4Kqc4KuA4KqTIOCqruCqvuCqn+CrhyBDbGljayDgqpXgqrDgq4tkAgMPFgIfAQIBFgJmD2QWAmYPFQN74KqX4Kq+4Kqu4Kqo4KuLIOCqteCqv+CqleCqvuCquCDgqoXgqqjgq4cg4KqX4Kq+4KquIOCqruCqvuCqgiDgqp/gq4fgqpXgqqjgq4vgqrLgq4vgqpzgq4Ag4KqP4KqV4Kqm4KquIOCqheCqp+CqpOCqqCDgqpvgq4cuBlRBUkVTSAdNRUhTQU5BZGS+jZObQn084shGOxoN/oTjIspivBmothWhSXwhYAYuFA==" />
</div>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="869165D0" />
</div>
        <!-- Header : START -->
        

<header class="header-style-1">
    <!-- ============================================== TOP MENU ============================================== -->
    <div class="top-bar animate-dropdown">
        <div class="container">
            <div class="header-top-inner">
                <div class="cnt-account" style="color: darkblue;">
                    
                    <script>
                        var blink_speed = 500;
                        var t = setInterval(function () {
                            var ele = document.getElementById('blinker');
                            ele.style.visibility = (ele.style.visibility == 'hidden' ? '' : 'hidden');
                        }, blink_speed);
                    </script>
                    <a id="blinker" href="https://anyror.gujarat.gov.in/" target="_blank">૭ / ૧૨ ના ઉતારા મેળવવા માટે અહિંયા ક્લિક કરો. </a>
					<a id="blinker" href="http://epaper.divyabhaskar.co.in/" target="_blank">કૃપા કરીને અહીં ક્લિક કરો અને અખબાર જુઓ </a>
					
                </div>
                <!-- /.cnt-account -->

                
                <!-- /.cnt-cart -->
                <div class="clearfix"></div>
            </div>
            <!-- /.header-top-inner -->
        </div>
        <!-- /.container -->
    </div>
    <!-- /.header-top -->
    <!-- ============================================== TOP MENU : END ============================================== -->
    <div class="main-header">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-9 logo-holder">
                    <div class="logo">
                        <a href="index.php">
                             <p><font size="6"> અજરાપુરા ગ્રામ પંચાયત</font></p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-3 social">
                    <ul class="link" style="margin-top: 20px;">
                        <li class="instagram pull-right"><a target="_blank" rel="nofollow" href="https://www.instagram.com/" title="Instagram"></a></li>
                        <li class="tw pull-right"><a target="_blank" rel="nofollow" href="https://twitter.com/" title="Twitter"></a></li>
                        <li class="fb pull-right"><a target="_blank" rel="nofollow" href="https://www.facebook.com/" title="Facebook"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="header-nav animate-dropdown">
        <div class="container">
            <div class="yamm navbar navbar-default" role="navigation">
                <div class="navbar-header">
                    <button data-target="#mc-horizontal-menu-collapse" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                        <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
                    </button>
                </div>
                <div class="nav-bg-class">
                    <div class="navbar-collapse collapse" id="mc-horizontal-menu-collapse">
                        <div class="nav-outer">
                            <ul class="nav navbar-nav">
                                <li id="Header_A1" class="dropdown "><a href="index.php">મુખ્ય પૃષ્ઠ</a></li>
                                <li id="Header_A2" class="dropdown"><a href="history.php">ઈતિહાસ</a></li>
                                <li id="Header_A3" class="active"><a href="dharohar.php">ધરોહર</a></li>
                                <li id="Header_A4" class="dropdown"><a href="activities.php">પ્રવ્રુતિઓ</a></li>
                                <li id="Header_A13" class="dropdown"><a href="achievements.php">સિદ્ધિઓ</a> </li>
                                <li id="Header_A5" class="dropdown"><a href="javascript:void(0);" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown">પદાધિકારી</a>
                                    <ul class="dropdown-menu pages">
                                        <li>
                                            <div class="yamm-content">
                                                <div class="row">
                                                    <div class="col-xs-12 col-menu">
                                                        <ul class="links">
                                                            <li><a href="sabhya.php">પંચાયત</a></li>
                                                           
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li id="Header_A6" class="dropdown"><a href="govproject.php">યોજનાઓ</a> </li>
                                <li id="Header_A7" class="dropdown"><a href="development.php">વિકાસના કામ</a> </li>
                                <li id="Header_A8" class="dropdown"><a href="bloodgroup.php">બ્લડ ગ્રુપની માહિતી</a> </li>
                                <li id="Header_A9" class="dropdown"><a href="akarni.php">મિલ્કત આકરણી</a> </li>
                                <li id="Header_A10" class="dropdown"><a href="feedback.php">અભિપ્રાય</a> </li>
                                <li id="Header_A11" class="dropdown"><a href="complaint.php">ફરીયાદ</a> </li>
                                <li id="Header_A12" class="dropdown"><a href="contact.php">સંપર્ક</a> </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

        <!-- Header : END -->
        
<div class="breadcrumb">
    <div class="container">
        <div class="breadcrumb-inner">
            <ul class="list-inline list-unstyled">
                
            </ul>
        </div>
    </div>
</div>

        <!-- Content : START -->
        <div class="body-content">
            <div class="container">
                <div class="row">
                    <div class="blog-page">
                        <div class="col-md-9">
                            <?php
												if (!empty($place_data)) {
										foreach ($place_data as $val) {
														?>
                                    <div class="blog-post outer-bottom-xs wow fadeInUp">
                                        <a href="blog-details.html">
                                            <img class="img-responsive" src="images/banner/<?php echo $val['tImage']; ?>" alt="પ્રવેશદ્વાર" /></a>
                                        <h1><a href="javascript:void(0);"><?php echo $val['place_name']; ?></a></h1>
                                        <span class="date-time">સ્થાપના સને  <?php echo $val['place_date']; ?></span>
                                        <p><?php echo $val['place_detail']; ?></p>
                                    </div>
                                <?php
										}
								}
														?>
                                    
                                    
                                   
                                
                                    
                            <div class="clearfix blog-pagination filters-container  wow fadeInUp" style="padding: 0px; background: none; box-shadow: none; margin-top: 15px; border: none">
                                <div class="text-right">
                                    <div class="pagination-container">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Sidebar : START -->
                    

<div class="col-xs-12 col-sm-12 col-md-3 sidebar">
    <div class="sidebar-widget hot-deals wow fadeInUp outer-bottom-xs">
        <h3 class="section-title">માનનીય</h3>
        <div class="owl-carousel sidebar-carousel custom-carousel owl-theme outer-top-ss">
		<?php
												if (!empty($minister_data)) {
										foreach ($minister_data as $val) {
														?>
            <div class="item">
                <div class="products">
                    <div class="hot-deal-wrapper">
                        <div class="image">
                            <img src="images/banner/<?php echo $val['tImage']; ?>" alt="મુખ્ય મંત્રી" />
                        </div>
                    </div>
                    <div class="product-info text-left m-t-20">
                        <p><?php echo $val['minister_category']; ?>,</p>
                        <div class="product-price">
                            <span class="price"><?php echo $val['minister_name']; ?></span>
                        </div>
                    </div>
                </div>
            </div>
			<?php
										}
								}
														?>
            
            
        </div>
    </div>
	
    <div class="sidebar-widget product-tag wow fadeInUp outer-bottom-xs">
        <h3 class="section-title">Latest News</h3>
        <div class="sidebar-widget-body outer-top-xs">
            <div class="tag-list">
                <marquee id="scroll_news" behavior="scroll" direction="up" scrollamount="2">
                    <?php
												if (!empty($news_data)) {
										foreach ($news_data as $val) {
														?>
                            <div onMouseOver="document.getElementById('scroll_news').stop();" onMouseOut="document.getElementById('scroll_news').start();">
                                <a class="item" title="<?php echo $val['news_name']; ?>" href="govproject.html" target="_blank"><?php echo $val['news_name']; ?></a>
                            </div>
							<?php
										}
								}
														?>
                        
                </marquee>
            </div>
        </div>
    </div>
	
    <!----------- Testimonials------------->
    <div class="sidebar-widget wow fadeInUp outer-top-vs outer-bottom-vs">
        <div id="testimonial" class="advertisement">
            
                    <div class="item">
                        <div class="testimonials"><em>"</em>ગામનો વિકાસ અને ગામ માં ટેકનોલોજી એકદમ અધતન છે.<em>"</em></div>
                        <div class="clients_author">MAYUR<span>AJARAPURA</span> </div>
                    </div>
                
        </div>
    </div>
    
</div>

                    <!--Sidebar : END-->
                </div>
            </div>
        </div>
        <br />
        <!-- Footer : START -->
        
<footer id="footer" class="footer color-bg">
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">વિકાસના કામ માટે ડોનેશન</h4>
                    </div>
                    <div class="module-body">
                        <ul class="toggle-footer" style="">
                            <li class="media">
                                <div class="media-body">
                                    <p style="color:#ffffff;"><b>BANK NAME : </b>BANK OF BARODA</p>
                                </div>
                            </li>

                            <li class="media">
                                <div class="media-body">
                                    <p style="color:#ffffff;"><b>A/C NO : </b>54200100002374</p>
                                </div>
                            </li>

                            <li class="media">
                                <div class="media-body">
                                    <p style="color:#ffffff;"><b>IFSC CODE : </b>BARBORANCHH</p>
                                </div>
                            </li>

                        </ul>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">ગવર્મેન્ટ વેબ સાઈટ</h4>
                    </div>
                    <div class="module-body">
                        <ul class="list-unstyled">
                            <li class="first"><a title="ગ્રામ ગૃહનિર્માણ અને ગ્રામ વિકાસ વિભાગ" href="https://panchayat.gujarat.gov.in/panchayatvibhag/">ગ્રામ ગૃહનિર્માણ અને ગ્રામ વિકાસ વિભાગ</a></li>
                            <li class="first"><a title="ભારતીય ડાક" href="https://www.indiapost.gov.in/">ભારતીય ડાક</a></li>
                            <li class="first"><a title="નર્મદા, જળ સંપત્તિ, પાણી પુરવઠા અને કલ્પસર વિભાગ" href="https://guj-nwrws.gujarat.gov.in/">નર્મદા, જળ સંપત્તિ, પાણી પુરવઠા અને કલ્પસર વિભાગ</a></li>
                            <li class="first"><a title="ગુજરાત ઊર્જા વિકાસ નિગમ લિમિટેડ" href="http://www.gseb.com/">ગુજરાત ઊર્જા વિકાસ નિગમ લિમિટેડ</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-2">
                    <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">ગવર્મેન્ટ વેબ સાઈટ</h4>
                    </div>
                    <div class="module-body">
                        <ul class="list-unstyled">
                            <li class="first"><a title="મતદાર કાર્ડ" href="https://ceo.gujarat.gov.in/">ઓનલાઈન મતદાર કાર્ડ</a></li>
                            <li class="first"><a title="આધાર કાર્ડ" href="https://ceo.gujarat.gov.in/">ઓનલાઈન આધાર કાર્ડ</a></li>
                            <li class="first"><a title="Any ROR" href="https://anyror.gujarat.gov.in/">Any ROR</a></li>
                            <li class="first"><a title="i-ખેડૂત" href="https://ikhedut.gujarat.gov.in/">i-ખેડૂત</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3">
                     <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">તત્કાલીન સુવિધાના નંબર</h4>
                    </div>
                    <div class="module-body">
                        <ul class="list-unstyled">
                            <li class="first"><a href="javascript:void(0);" title="વિજાપુર તાલુકા પોલીસ સ્ટેશન">પોલીસ સ્ટેશન : (02763) 220016</a></li>
                            <li class="first"><a href="javascript:void(0);" title="નગરપાલિકા ફાયર  સ્ટેશન">નગરપાલિકા Fire : (02763) 220020</a></li>
                            <li class="first"><a href="javascript:void(0);" title="એ.પી.એમ.સી ફાયર સ્ટેશન">APMC Fire : 220190, 9429197651, 52</a></li>
                            <li class="first"><a href="javascript:void(0);" title="એ.પી.એમ.સી એમ્બુલન્સ">APMC Ambulance : 9824106796</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-bar">
        <div class="container">
            <div class="col-xs-12 col-sm-12 no-padding">
                <div class="clearfix">
                    <p style="color:white; text-align:center;">ALL RIGHTS RESERVED BY AJARAPURA GRAM PANCHAYAT <sup style="color:white;">®</sup></a> <br/>  
					<script type="text/javascript" src="http://counter.websiteout.net/js/15/0/532/1"></script></p>
                </div>
            </div>
        </div>
    </div>
</footer>

        <!-- Footer : END -->
    </form>
    

<script src="assets/js/jquery-1.11.1.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/bootstrap-hover-dropdown.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/echo.min.js"></script>
<script src="assets/js/jquery.easing-1.3.min.js"></script>
<script src="assets/js/bootstrap-slider.min.js"></script>
<script src="assets/js/jquery.rateit.min.js"></script>
<script type="text/javascript" src="assets/js/lightbox.min.js"></script>
<script src="assets/js/bootstrap-select.min.js"></script>
<script src="assets/js/wow.min.js"></script>
<script src="assets/js/scripts.js"></script>

</body>

<!-- Mirrored from www.jepurpanchayat.com/dharohar.aspx by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 04 May 2018 10:45:27 GMT -->
</html>
