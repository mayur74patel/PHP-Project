
<?php
session_start();
include 'commonincludefiles.php';
global $conn;
$minister_data = array();
$minister_data = getAllministerData();
$news_data = array();
$news_data = getAllnewsData();
$valid_data = array();
$valid_data = getAllvalidData();
$document_data = array();
$document_data = getAlldocumentData();
$yojna_data = array();
$yojna_data = getAllyojnaData();


?>


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from www.jepurpanchayat.com/govproject.aspx by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 04 May 2018 10:45:44 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <!-- Meta -->
    <meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" /><meta name="description" /><meta name="author" /><meta name="keywords" content="Jepur Gram Panchayat Vijapur, Gram Panchayat Jepur, Online Jepur Panchayat, Jepur Vijapur, Gram Panchayat Vijapur, Gram Panchayat Software, Jepur Vijapur Mehsana, Gujarat" /><meta name="robots" content="all" /><title>
	અજરાપુરા ગ્રામ પંચાયત
</title>

    <!-- Style Sheet : START -->
    

<!-- Bootstrap Core CSS -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
<!-- Customizable CSS -->
<link rel="stylesheet" href="assets/css/main.css" />
<link rel="stylesheet" href="assets/css/blue.css" />
<link rel="stylesheet" href="assets/css/owl.carousel.css" />
<link rel="stylesheet" href="assets/css/owl.transitions.css" />
<link rel="stylesheet" href="assets/css/animate.min.css" />
<link rel="stylesheet" href="assets/css/rateit.css" />
<link rel="stylesheet" href="assets/css/bootstrap-select.min.css" />
<link href="assets/css/lightbox.css" rel="stylesheet">

<!-- Icons/Glyphs -->
<link rel="stylesheet" href="assets/css/font-awesome.css" />

<!-- Fonts -->
<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css' />
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,600italic,700,700italic,800' rel='stylesheet' type='text/css' />
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css' />



    <!-- Style Sheet : START -->
</head>
<body class="cnt-home">
    <form method="post" action="http://www.jepurpanchayat.com/govproject.aspx" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUKMTA0OTY1ODQ0MQ9kFgICAw9kFgYCAQ9kFgICDQ8WAh4FY2xhc3MFBmFjdGl2ZWQCBQ8WAh4LXyFJdGVtQ291bnQCARYCZg9kFgJmDxUDQeCqluCrh+CqpOCrgOCqteCqvuCqoeCrgOCqqOCrgCDgqrXgqr/gqrXgqr/gqqcg4Kqv4KuL4Kqc4Kqo4Kq+4KqTJ+Crpy/gq6ov4Kun4KuuIOCqpeCrgCDgq6ngq6Yv4KuqL+Crp+CrrsAl4Kq14Kqw4KuN4Kq3IDog4Kuo4Kum4Kun4KuuLeCrp+CrryDgqq7gqr7gqp/gq4cg4KqW4KuH4Kqk4KuA4Kq14Kq+4Kqh4KuA4Kqo4KuAIOCqteCqv+CqteCqv+CqpyDgqq/gq4vgqpzgqqjgqr7gqpMg4Kqu4Kq+4Kqf4KuHIOCqk+CqqOCqsuCqvuCqh+CqqCDgqoXgqrDgqpzgq4DgqpMg4Kqk4Kq+4Kqw4KuA4KqWIDxiPuCrpy/gq6ov4Kuo4Kum4Kun4KuuIOCqpeCrgCDgq6ngq6Yv4KuqL+CrqOCrpuCrp+CrrjwvYj4g4Kq44KuB4Kqn4KuAIDxhIGhyZWY9J2h0dHBzOi8vaWtoZWR1dC5ndWphcmF0Lmdvdi5pbi8nIHRhcmdldD0nX2JsYW5rJz5pS2hlZHV0PC9hPg0KKOCqhuCqiCDgqpbgq4fgqqHgq4LgqqQg4Kqq4KuL4Kqw4KuN4Kqf4KqyKSDgqpbgq4HgqrLgq43gqrLgq4HgqoIg4Kqu4KuB4KqV4Kq14Kq+4Kqu4Kq+4KqCIOCqhuCqteCrh+CqsiDgqpvgq4cuIOCqpOCriyDgqpzgq4fgqqrgq4HgqrAg4KqX4Kq+4Kqu4Kqo4Kq+IOCqluCrh+CqoeCrguCqpCDgqq3gqr7gqojgqpPgqo8g4KqF4Kqw4Kqc4KuAIOCqleCqsOCqteCqviDgqqrgqoLgqprgqr7gqq/gqqQgVkNFKOCqleCri+CqruCrjeCqquCrjeCqr+CrgeCqn+CqsCDgqpPgqqrgqrDgq4fgqp/gqrApIOCqqOCriyDgqrjgqoLgqqrgqrDgq43gqpUg4KqV4Kqw4Kq14KuLLjxici8+PGJyLz4NCg0KPGI+4KqF4Kqw4Kqc4KuAIOCqleCqsOCqteCqviDgqpzgqrDgq4LgqrDgq4Ag4Kqh4KuL4KqV4KuN4Kqv4KuB4Kqu4KuH4Kqo4KuN4KqfPC9iPiA8YnIvPjxici8+DQrgq6cpICDgq64g4KqFIOCqqOCriyDgqongqqTgqr7gqrDgq4sgPGJyLz4NCuCrqCkgIOCqhuCqp+CqvuCqsOCqleCqvuCqsOCrjeCqoSDgqqjgq4Ag4Kqo4KqV4KqyIOCqq+CqsOCqnOCrgOCqr+CqvuCqpDxici8+DQrgq6kpICDgqqzgq4fgqqjgq43gqpUg4Kqq4Kq+4Kq44Kqs4KuB4KqV4Kqo4KuAIOCqqOCqleCqsiA8YnIvPg0K4KuqKSAg4Kqw4KuH4Kq24Kqo4KqV4Kq+4Kqw4KuN4Kqh4Kqo4KuAIOCqqOCqleCqsiA8YnIvPg0K4KurKSAg4Kqu4KuL4Kqs4Kq+4KqH4KqyIOCqqOCqguCqrOCqsCDgqqvgqrDgqpzgq4Dgqq/gqr7gqqQg4Kqy4KqW4Kq14KuLPGJyLz48YnIvPg0KDQo8Yj7gqpbgqr7gqrgg4Kqo4KuL4KqC4KqnIDogPC9iPuCqheCqsOCqnOCrgCDgqpXgqrDgq4Dgqqjgq4cg4KqX4KuN4Kqw4Kq+4Kqu4Kq44KuH4Kq14KqVIOCqhuCqquCrgCDgqqbgq4fgqrXgq4A8YnIvPjxici8+DQoNCuCqluCrh+CqpOCrgOCqteCqvuCqoeCrgCDgqqjgq4Ag4Kqv4KuL4Kqc4Kqo4Kq+4KqTOi08YnIvPjxici8+DQowMS4gIOCqheCqqOCrjeCqoeCqsCDgqpfgq43gqrDgqr7gqongqqjgq43gqqEg4Kqq4Kq+4KqH4KqqIOCqsuCqvuCqh+CqqC3gqqrgq4Au4Kq14KuALuCquOCrgDxici8+DQowMi4gIOCqj+Cqri4g4Kqs4KuALiDgqqrgq43gqrLgqr7gqokgKOCqruCrgOCqleCrh+CqqOCrgOCqleCqsiDgqrDgq4DgqrXgqrDgq43gqrjgq4DgqqzgqrI8YnIvPg0KMDMuICDgqo/gqq4u4Kqs4KuALiDgqqrgq43gqrLgqr7gqok8YnIvPg0KMDQuICDgqo/gqq4u4Kqs4KuALiDgqqrgq43gqrLgqr7gqokgKOCqueCqvuCqr+CqoeCrjeCqsOCri+CqsuCrgOCqlSDgqrDgq4DgqrXgqrDgq43gqrjgq4DgqqzgqrIpPGJyLz4NCjA1LiAg4KqT4Kqf4KuL4Kqu4KuH4Kqf4KuA4KqVIOCquOCrgOCqoSDgqpXgqq4g4Kqr4Kqw4KuN4Kqf4KuA4Kqy4Kq+4KqH4Kqd4KqwIOCqoeCrjeCqsOCrgOCqsjxici8+DQowNi4gIOCqk+Cqn+Cri+CqruCrh+Cqn+CrgOCqlSDgqrjgq4DgqqEg4KqV4KquIOCqq+CqsOCrjeCqn+CrgOCqsuCqvuCqiOCqneCqsCDgqqrgq43gqrLgqr7gqoLgqp/gqrA8YnIvPg0KMDcuICDgqpPgqp/gq4vgqq7gq4fgqp/gq4DgqpUg4Kq44KuA4KqhIOCqoeCrjeCqsOCrgOCqsjxici8+DQowOC4gIOCqleCqsuCrjeCqn+CrgOCqteCrh+Cqn+CqsDxici8+DQowOS4gIOCqleCrjeCqsuCrgOCqqOCqsCDgqpXgqq4g4KqX4KuN4Kqw4KuH4Kqh4KqwPGJyLz4NCjEwLiAg4KqW4KuB4Kqy4KuN4Kqy4KuAIOCqquCqvuCqh+CqquCqsuCqvuCqh+CqqDxici8+DQoxMS4gIOCql+CrjeCqsOCqvuCqieCqqOCrjeCqoeCqqOCqnyDgqqHgq4DgqpfgqrA8YnIvPg0KMTIuICDgqprgqr7gqqsg4KqV4Kqf4KqwICjgqo/gqoLgqpzgqr/gqqgv4KqI4Kqy4KuHLiDgqq7gq4vgqp/gqrAg4KqT4Kqq4Kqw4KuH4Kqf4KuH4KqhKTxici8+DQoxMy4gIOCqmuCqvuCqqyDgqpXgqp/gqrAgKOCqn+CrjeCqsOCrh+CqleCqn+CqsC/gqqrgqr7gqrXgqrAg4Kqf4KuA4Kqy4KqwIOCqk+CqquCqsOCrh+Cqn+Crh+CqoSk8YnIvPg0KMTQuICDgqprgq4Dgqp3gqrIg4Kqq4KuN4Kqy4Kq+4KqJPGJyLz4NCjE1LiAg4Kqd4KuA4Kqw4KuLIOCqn+CrgOCqsiDgqrjgq4DgqqEg4KqV4KquIOCqq+CqsOCrjeCqn+CrgOCqsuCqvuCqh+CqneCqsCDgqqHgq43gqrDgq4DgqrI8YnIvPg0KMTYuICDgqp3gq4DgqrDgq4sg4Kqf4KuA4KqyIOCquOCrgOCqoSDgqpXgqq4g4Kqr4Kqw4KuN4Kqf4KuA4Kqy4Kq+4KqI4Kqd4KqwIOCqquCrjeCqsuCqvuCqguCqn+CqsDxici8+DQoxNy4gIOCqneCrgOCqsOCriyDgqp/gq4DgqrIg4Kq44KuA4KqhIOCqoeCrjeCqsOCrgOCqsjxici8+DQoxOC4gIOCqn+CrjeCqsOCrh+CqleCqn+CqsDxici8+DQoxOS4gIOCqoeCrgOCquOCrjeCqlSDgqqrgq43gqrLgqr7gqok8YnIvPg0KMjAuICDgqqHgq4Dgqrjgq43gqpUg4Kq54KuH4Kqw4KuLPGJyLz4NCjIxLiAg4Kqk4Kq+4Kqh4Kqq4Kqk4KuN4Kqw4KuAPGJyLz4NCjIyLiAg4Kqq4KuH4Kqh4KuAIOCqn+CrjeCqsOCqvuCqqOCrjeCquCDgqqrgq43gqrLgqr7gqqjgq43gqp/gqrAgKOCquOCrh+CqsuCrjeCqqyDgqqrgq43gqrDgq4vgqqrgq4fgqrLgq43gqqEpPGJyLz4NCjIzLiAg4Kqq4Kqu4KuN4KqqIOCquOCrh+Cqn+CrjeCquDxici8+DQoyNC4gIOCqquCrjeCqsOCri+CquOCrh+CquOCrgOCqguCqlyDgqq/gq4Lgqqjgqr/gqp88YnIvPg0KMjUuICDgqqrgq43gqrLgqr7gqok8YnIvPg0KMjYuICDgqqrgqr7gqpUg4Kq44KqC4Kqw4KqV4KuN4Kq34KqjIOCquOCqvuCqp+CqqOCriy0g4Kqq4Kq+4Kq14KqwIOCquOCqguCqmuCqvuCqsuCrgOCqpDxici8+DQoyNy4gIOCqquCqvuCqteCqsCDgqp/gq4DgqrLgqrA8YnIvPg0KMjguICDgqqrgqr7gqrXgqrAg4Kql4KuN4Kqw4KuH4Kq44KqwPGJyLz4NCjI5LiAg4Kqq4Kq+4Kq14KqwIOCqteCrgOCqoeCqsCAo4Kq44KuH4Kqy4KuN4KqrIOCqquCrjeCqsOCri+CqquCrh+CqsuCrjeCqoSk8YnIvPg0KMzAuICDgqqrgq4vgqp/gq4fgqp/gq4sg4Kqh4KuA4KqX4KqwPGJyLz4NCjMxLiAg4Kqq4KuL4Kqf4KuH4Kqf4KuLIOCqquCrjeCqsuCqvuCqqOCrjeCqn+CqsDxici8+DQozMi4gIOCqquCri+CquOCrjeCqnyDgqrngq4vgqrIg4Kqh4KuA4KqX4KqwPGJyLz4NCjMzLiAg4Kqr4Kqw4KuN4Kqf4KuA4Kqy4Kq+4KqI4Kqd4KqwIOCqrOCrjeCqsOCri+CqoeCqleCqvuCquOCrjeCqn+CqsDxici8+DQozNC4gIOCqq+CqsOCriyDgqpPgqqrgqqjgqrA8YnIvPg0KMzUuICDgqqzgqoLgqqEg4Kqr4KuL4Kqw4KuN4Kqu4KqwPGJyLz4NCjM2LiAg4Kqs4KuN4Kqw4Kq4IOCqleCqn+CqsDxici8+DQozNy4gIOCqrOCrjeCqsuCrh+CqoSDgqrngq4fgqrDgq4s8YnIvPg0KMzguICDgqqzgq4fgqrLgqrAgKOCqn+CrjeCqsOCrh+CqleCqn+CqsCDgqrjgqoLgqprgqr7gqrLgqr/gqqQ8YnIvPg0KMzkuICDgqq7gqrLgq43gqp/gq4Ag4KqV4KuN4Kqw4KuL4KqqIOCqquCrjeCqsuCqvuCqqOCrjeCqn+CqsDxici8+DQo0MC4gIOCqruCri+CqrOCqvuCqh+CqsiDgqrbgq43gqrDgq4fgqqHgqrA8YnIvPg0KNDEuICDgqrDgq4fgqofgqp3gqqEg4Kqs4KuH4KqhIOCqquCrjeCqsuCqvuCqqOCrjeCqn+CqsDxici8+DQo0Mi4gIOCqsOCrh+CqnSAmIOCqq+CqsOCriyDgqqrgq43gqrLgqr7gqqjgq43gqp/gqrAgPGJyLz4NCjQzLiAg4Kqw4KuA4Kqd4KqwPGJyLz4NCjQ0LiAg4Kqw4KuA4Kqq4KqwICjgqp/gq43gqrDgq4fgqpXgq43gqp/gqrAg4Kqr4KuN4Kqw4KqC4KqfIOCqruCqvuCqieCqguCqn+Crh+CqoSk8YnIvPg0KNDUuICDgqrDgq4DgqqrgqrAgKOCquOCrh+CqsuCrjeCqqyDgqqrgq43gqrDgq4vgqqrgq4fgqrLgq43gqqEpPGJyLz4NCjQ2LiDgqrDgq4DgqqrgqrAg4KqV4KquIOCqrOCqvuCqh+CqguCqoeCqsDxici8+DQo0Ny4gIOCqsOCri+Cqn+CqsOCrgCDgqqrgq43gqrLgqr7gqok8YnIvPg0KNDguICDgqrDgq4vgqp/gqrDgq4Ag4Kqh4KuA4Kq44KuN4KqVIOCqueCrh+CqsOCrizxici8+DQo0OS4gIOCqsOCri+Cqn+CqsOCrgCDgqqrgqr7gqrXgqrAg4Kqf4KuA4Kqy4KqwICjgqrjgq4fgqrLgq43gqqsg4Kqq4KuN4Kqw4KuL4Kqq4KuH4Kqy4KuN4KqhKTxici8+DQo1MC4gIOCqsOCri+Cqn+CqsOCrgCDgqqrgqr7gqrXgqrAg4Kq54KuH4Kqw4KuLPGJyLz4NCjUxLiAg4Kqw4KuL4Kqf4Kq+4Kq14KuH4Kqf4KqwPGJyLz4NCjUyLiAg4Kqy4KuH4Kqo4KuN4KqhIOCqsuCrh+CqteCqsuCqsDxici8+DQo1My4gIOCqsuCrh+CquOCqsCDgqrLgq4fgqqjgq43gqqEg4Kqy4KuH4Kq14Kqy4KqwPGJyLz4NCjU0LiAg4Kq14Kq/4Kqo4KuL4Kq14KuA4KqC4KqXIOCqq+Crh+CqqDxici8+DQo1NS4gIOCqtuCrjeCqsOCrh+CqoeCqsDxici8+DQo1Ni4gIOCquOCrjeCqn+CqrOCqsiDgqrjgq4fgqrXgqrA8YnIvPg0KNTcuICDgqrjgqqzgqrjgq4vgqojgqrLgqrA8YnIvPg0KNTguICDgqrjgq43gqrLgq4fgqrbgqrA8YnIvPg0KNTkuICDgqrngq4fgqqjgq43gqqEg4Kqf4KuC4Kqy4KuN4Kq4IOCqleCqv+Cqnzxici8+DQo2MC4gIOCqueCrh+CqsOCriyAo4Kqw4Kq+4KqqKTxici8+ZAIHD2QWBAIBDxYCHwECARYCZg9kFgJmDxUDtwHgqrXgqrDgq43gqrcgOiDgq6jgq6bgq6fgq64t4Kun4KuvIOCqruCqvuCqn+CrhyDgqpbgq4fgqqTgq4DgqrXgqr7gqqHgq4Dgqqjgq4Ag4Kq14Kq/4Kq14Kq/4KqnIOCqr+Cri+CqnOCqqOCqvuCqk+CqqOCrgCDgqpPgqqjgqrLgqr7gqofgqqgg4KqF4Kqw4Kqc4KuA4KqTIOCqruCqvuCqn+CrhyBDbGljayDgqpXgqrDgq4staHR0cDovL3d3dy5qZXB1cnBhbmNoYXlhdC5jb20vZ292cHJvamVjdC5hc3B4twHgqrXgqrDgq43gqrcgOiDgq6jgq6bgq6fgq64t4Kun4KuvIOCqruCqvuCqn+CrhyDgqpbgq4fgqqTgq4DgqrXgqr7gqqHgq4Dgqqjgq4Ag4Kq14Kq/4Kq14Kq/4KqnIOCqr+Cri+CqnOCqqOCqvuCqk+CqqOCrgCDgqpPgqqjgqrLgqr7gqofgqqgg4KqF4Kqw4Kqc4KuA4KqTIOCqruCqvuCqn+CrhyBDbGljayDgqpXgqrDgq4tkAgMPFgIfAQIBFgJmD2QWAmYPFQN74KqX4Kq+4Kqu4Kqo4KuLIOCqteCqv+CqleCqvuCquCDgqoXgqqjgq4cg4KqX4Kq+4KquIOCqruCqvuCqgiDgqp/gq4fgqpXgqqjgq4vgqrLgq4vgqpzgq4Ag4KqP4KqV4Kqm4KquIOCqheCqp+CqpOCqqCDgqpvgq4cuBlRBUkVTSAdNRUhTQU5BZGT/231KCZ1xGVNKFthevguGjyb3CSGuTv67pm3Wds8oQg==" />
</div>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="412DC32A" />
</div>
        <!-- Header : START -->
        

<header class="header-style-1">
    <!-- ============================================== TOP MENU ============================================== -->
    <div class="top-bar animate-dropdown">
        <div class="container">
            <div class="header-top-inner">
                <div class="cnt-account" style="color: darkblue;">
                    
                    <script>
                        var blink_speed = 500;
                        var t = setInterval(function () {
                            var ele = document.getElementById('blinker');
                            ele.style.visibility = (ele.style.visibility == 'hidden' ? '' : 'hidden');
                        }, blink_speed);
                    </script>
                    <a id="blinker" href="https://anyror.gujarat.gov.in/" target="_blank">૭ / ૧૨ ના ઉતારા મેળવવા માટે અહિંયા ક્લિક કરો. </a>
					<a id="blinker" href="http://epaper.divyabhaskar.co.in/" target="_blank">કૃપા કરીને અહીં ક્લિક કરો અને અખબાર જુઓ </a>
					
                </div>
                <!-- /.cnt-account -->

                
                <!-- /.cnt-cart -->
                <div class="clearfix"></div>
            </div>
            <!-- /.header-top-inner -->
        </div>
        <!-- /.container -->
    </div>
    <!-- /.header-top -->
    <!-- ============================================== TOP MENU : END ============================================== -->
    <div class="main-header">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-9 logo-holder">
                    <div class="logo">
                        <a href="index.php">
                             <p><font size="6"> અજરાપુરા ગ્રામ પંચાયત</font></p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-3 social">
                    <ul class="link" style="margin-top: 20px;">
                        <li class="instagram pull-right"><a target="_blank" rel="nofollow" href="https://www.instagram.com/" title="Instagram"></a></li>
                        <li class="tw pull-right"><a target="_blank" rel="nofollow" href="https://twitter.com/" title="Twitter"></a></li>
                        <li class="fb pull-right"><a target="_blank" rel="nofollow" href="https://www.facebook.com/" title="Facebook"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="header-nav animate-dropdown">
        <div class="container">
            <div class="yamm navbar navbar-default" role="navigation">
                <div class="navbar-header">
                    <button data-target="#mc-horizontal-menu-collapse" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                        <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
                    </button>
                </div>
                <div class="nav-bg-class">
                    <div class="navbar-collapse collapse" id="mc-horizontal-menu-collapse">
                        <div class="nav-outer">
                            <ul class="nav navbar-nav">
                                <li id="Header_A1" class="dropdown "><a href="index.php">મુખ્ય પૃષ્ઠ</a></li>
                                <li id="Header_A2" class="dropdown"><a href="history.php">ઈતિહાસ</a></li>
                                <li id="Header_A3" class="dropdown"><a href="dharohar.php">ધરોહર</a></li>
                                <li id="Header_A4" class="dropdown"><a href="activities.php">પ્રવ્રુતિઓ</a></li>
                                <li id="Header_A13" class="dropdown"><a href="achievements.php">સિદ્ધિઓ</a> </li>
                                <li id="Header_A5" class="dropdown"><a href="javascript:void(0);" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown">પદાધિકારી</a>
                                    <ul class="dropdown-menu pages">
                                        <li>
                                            <div class="yamm-content">
                                                <div class="row">
                                                    <div class="col-xs-12 col-menu">
                                                        <ul class="links">
                                                            <li><a href="sabhya.php">પંચાયત</a></li>
                                                            <li><a href="javascript:void(0);">જાહેર સંસ્થા</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li id="Header_A6" class="active"><a href="govproject.php">યોજનાઓ</a> </li>
                                <li id="Header_A7" class="dropdown"><a href="development.php">વિકાસના કામ</a> </li>
                                <li id="Header_A8" class="dropdown"><a href="bloodgroup.php">બ્લડ ગ્રુપની માહિતી</a> </li>
                                <li id="Header_A9" class="dropdown"><a href="akarni.php">મિલ્કત આકરણી</a> </li>
                                <li id="Header_A10" class="dropdown"><a href="feedback.php">અભિપ્રાય</a> </li>
                                <li id="Header_A11" class="dropdown"><a href="complaint.php">ફરીયાદ</a> </li>
                                <li id="Header_A12" class="dropdown"><a href="contact.php">સંપર્ક</a> </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

        <!-- Header : END -->
        
<div class="breadcrumb">
    <div class="container">
        <div class="breadcrumb-inner">
            <ul class="list-inline list-unstyled">
                
            </ul>
        </div>
    </div>
</div>

        <!-- Content : START -->
        <div class="body-content">
            <div class="container">
                <div class="row">
                    <div class="blog-page">
                        <div class="col-md-9">
                            
                                    <div class="blog-post wow fadeInUp">
                                        <h1><a href="javascript:void(0);">ખેતીવાડીની વિવિધ યોજનાઓ</a></h1>
										<?php
												if (!empty($valid_data)) {
										foreach ($valid_data as $val) {
														?>
                                        <span class="date-time"><?php echo $val['valid_start']; ?> થી <?php echo $val['valid_end']; ?></span>
										<?php
												}
								}
								?>
								<?php
												if (!empty($valid_data)) {
										foreach ($valid_data as $val) {
														?>
                                        <p>વર્ષ : ૨૦૧૮-૧૯ માટે ખેતીવાડીની વિવિધ યોજનાઓ માટે ઓનલાઇન અરજીઓ તારીખ <b><?php echo $val['valid_start']; ?> થી <?php echo $val['valid_end']; ?></b> સુધી <a href='https://ikhedut.gujarat.gov.in/' target='_blank'>iKhedut</a>
(આઈ ખેડૂત પોર્ટલ) ખુલ્લું મુકવામાં આવેલ છે. તો જેપુર ગામના ખેડૂત ભાઈઓએ અરજી કરવા પંચાયત VCE(કોમ્પ્યુટર ઓપરેટર) નો સંપર્ક કરવો.<br/><br/><?php
												}
								}
								?>

<b>અરજી કરવા જરૂરી ડોક્યુમેન્ટ</b> <br/><br/>
<?php
												if (!empty($document_data)) {
										foreach ($document_data as $val) {
														?>
<?php echo $val['iCategoryID']; ?>)  <?php echo $val['document_name']; ?> <br/>
૨)  આધારકાર્ડ ની નકલ ફરજીયાત<br/>
<?php
												}
								}
								?>
<b>ખાસ નોંધ : </b>અરજી કરીને ગ્રામસેવક આપી દેવી<br/><br/>

ખેતીવાડી ની યોજનાઓ:-<br/><br/>
<?php
												if (!empty($yojna_data)) {
										foreach ($yojna_data as $val) {
														?>
<?php echo $val['iCategoryID']; ?>.&nbsp<a id="blinker" href="<?php echo $val['yojna_link']; ?> " target="_blank"><?php echo $val['yojna_name']; ?>. </a>
<br/>
<?php
												}
								}
								?>

</p>
                                        <a href="#" class="btn btn-upper btn-primary read-more">Download</a>
                                    </div>
                                    <div class="clearfix blog-pagination filters-container  wow fadeInUp" style="padding: 0px; background: none; box-shadow: none; margin-top: 15px; border: none">
                                        <div class="text-right">
                                            <div class="pagination-container">
                                            </div>
                                        </div>
                                    </div>
                                
                        </div>
                    </div>
                    <!-- Sidebar : START -->
                    
<div class="col-xs-12 col-sm-12 col-md-3 sidebar">
    <div class="sidebar-widget hot-deals wow fadeInUp outer-bottom-xs">
        <h3 class="section-title">માનનીય</h3>
        <div class="owl-carousel sidebar-carousel custom-carousel owl-theme outer-top-ss">
		<?php
												if (!empty($minister_data)) {
										foreach ($minister_data as $val) {
														?>
            <div class="item">
                <div class="products">
                    <div class="hot-deal-wrapper">
                        <div class="image">
                            <img src="images/banner/<?php echo $val['tImage']; ?>" alt="મુખ્ય મંત્રી" />
                        </div>
                    </div>
                    <div class="product-info text-left m-t-20">
                        <p><?php echo $val['minister_category']; ?>,</p>
                        <div class="product-price">
                            <span class="price"><?php echo $val['minister_name']; ?></span>
                        </div>
                    </div>
                </div>
            </div>
			<?php
										}
								}
														?>
            
            
        </div>
    </div>
	
    <div class="sidebar-widget product-tag wow fadeInUp outer-bottom-xs">
        <h3 class="section-title">Latest News</h3>
        <div class="sidebar-widget-body outer-top-xs">
            <div class="tag-list">
                <marquee id="scroll_news" behavior="scroll" direction="up" scrollamount="2">
                    <?php
												if (!empty($news_data)) {
										foreach ($news_data as $val) {
														?>
                            <div onMouseOver="document.getElementById('scroll_news').stop();" onMouseOut="document.getElementById('scroll_news').start();">
                                <a class="item" title="<?php echo $val['news_name']; ?>" href="govproject.html" target="_blank"><?php echo $val['news_name']; ?></a>
                            </div>
							<?php
										}
								}
														?>
                        
                </marquee>
            </div>
        </div>
    </div>
	
    <!----------- Testimonials------------->
    <div class="sidebar-widget wow fadeInUp outer-top-vs outer-bottom-vs">
        <div id="testimonial" class="advertisement">
            
                    <div class="item">
                        <div class="testimonials"><em>"</em>ગામનો વિકાસ અને ગામ માં ટેકનોલોજી એકદમ અધતન છે.<em>"</em></div>
                        <div class="clients_author">MAYUR<span>AJARAPURA</span> </div>
                    </div>
                
        </div>
    </div>
    
</div>

                    <!--Sidebar : END-->
                </div>
            </div>
        </div>
        <br />
        <!-- Footer : START -->
        
<footer id="footer" class="footer color-bg">
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">વિકાસના કામ માટે ડોનેશન</h4>
                    </div>
                    <div class="module-body">
                        <ul class="toggle-footer" style="">
                            <li class="media">
                                <div class="media-body">
                                    <p style="color:#ffffff;"><b>BANK NAME : </b>BANK OF BARODA</p>
                                </div>
                            </li>

                            <li class="media">
                                <div class="media-body">
                                    <p style="color:#ffffff;"><b>A/C NO : </b>******************</p>
                                </div>
                            </li>

                            <li class="media">
                                <div class="media-body">
                                    <p style="color:#ffffff;"><b>IFSC CODE : </b>BARBORANCHH</p>
                                </div>
                            </li>

                        </ul>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">ગવર્મેન્ટ વેબ સાઈટ</h4>
                    </div>
                    <div class="module-body">
                        <ul class="list-unstyled">
                            <li class="first"><a title="ગ્રામ ગૃહનિર્માણ અને ગ્રામ વિકાસ વિભાગ" href="https://panchayat.gujarat.gov.in/panchayatvibhag/">ગ્રામ ગૃહનિર્માણ અને ગ્રામ વિકાસ વિભાગ</a></li>
                            <li class="first"><a title="ભારતીય ડાક" href="https://www.indiapost.gov.in/">ભારતીય ડાક</a></li>
                            <li class="first"><a title="નર્મદા, જળ સંપત્તિ, પાણી પુરવઠા અને કલ્પસર વિભાગ" href="https://guj-nwrws.gujarat.gov.in/">નર્મદા, જળ સંપત્તિ, પાણી પુરવઠા અને કલ્પસર વિભાગ</a></li>
                            <li class="first"><a title="ગુજરાત ઊર્જા વિકાસ નિગમ લિમિટેડ" href="http://www.gseb.com/">ગુજરાત ઊર્જા વિકાસ નિગમ લિમિટેડ</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-2">
                    <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">ગવર્મેન્ટ વેબ સાઈટ</h4>
                    </div>
                    <div class="module-body">
                        <ul class="list-unstyled">
                            <li class="first"><a title="મતદાર કાર્ડ" href="https://ceo.gujarat.gov.in/">ઓનલાઈન મતદાર કાર્ડ</a></li>
                            <li class="first"><a title="આધાર કાર્ડ" href="https://ceo.gujarat.gov.in/">ઓનલાઈન આધાર કાર્ડ</a></li>
                            <li class="first"><a title="Any ROR" href="https://anyror.gujarat.gov.in/">Any ROR</a></li>
                            <li class="first"><a title="i-ખેડૂત" href="https://ikhedut.gujarat.gov.in/">i-ખેડૂત</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3">
                     <div class="module-heading">
                        <h4 class="module-title" style="color:#d0205e;">તત્કાલીન સુવિધાના નંબર</h4>
                    </div>
                    <div class="module-body">
                        <ul class="list-unstyled">
                            <li class="first"><a href="javascript:void(0);" title="વિજાપુર તાલુકા પોલીસ સ્ટેશન">પોલીસ સ્ટેશન : (02763) 220016</a></li>
                            <li class="first"><a href="javascript:void(0);" title="નગરપાલિકા ફાયર  સ્ટેશન">નગરપાલિકા Fire : (02763) 220020</a></li>
                            <li class="first"><a href="javascript:void(0);" title="એ.પી.એમ.સી ફાયર સ્ટેશન">APMC Fire : 220190, 9429197651, 52</a></li>
                            <li class="first"><a href="javascript:void(0);" title="એ.પી.એમ.સી એમ્બુલન્સ">APMC Ambulance : 9824106796</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-bar">
        <div class="container">
            <div class="col-xs-12 col-sm-12 no-padding">
                <div class="clearfix">
                    <p style="color:white; text-align:center;">ALL RIGHTS RESERVED BY AJARAPURA GRAM PANCHAYAT <sup style="color:white;">®</sup></a> <br/>  
					<script type="text/javascript" src="http://counter.websiteout.net/js/15/0/532/1"></script></p>
                </div>
            </div>
        </div>
    </div>
</footer>

        <!-- Footer : END -->
    </form>
    

<script src="assets/js/jquery-1.11.1.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/bootstrap-hover-dropdown.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/echo.min.js"></script>
<script src="assets/js/jquery.easing-1.3.min.js"></script>
<script src="assets/js/bootstrap-slider.min.js"></script>
<script src="assets/js/jquery.rateit.min.js"></script>
<script type="text/javascript" src="assets/js/lightbox.min.js"></script>
<script src="assets/js/bootstrap-select.min.js"></script>
<script src="assets/js/wow.min.js"></script>
<script src="assets/js/scripts.js"></script>

</body>

<!-- Mirrored from www.jepurpanchayat.com/govproject.aspx by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 04 May 2018 10:45:44 GMT -->
</html>
