<?php

$CATEGORY_IMAGE_PATH = $_SERVER['DOCUMENT_ROOT']."/Ajarapura/images/banner/";
$CATEGORY_IMAGE_URL = "images/banner/";

$SUBCATEGORY_IMAGE_PATH = $_SERVER['DOCUMENT_ROOT']."/fantasticservices/images/subcategory/";
$SUBCATEGORY_IMAGE_URL = "images/subcategory/";

$USER_IMAGE_PATH = $_SERVER['DOCUMENT_ROOT']."/fantasticservices/images/user/";
$USER_IMAGE_URL = "images/user/";

$SUBCATEGORY_DATA_IMAGE_PATH = $_SERVER['DOCUMENT_ROOT']."/fantasticservices/images/subcategorydata/";
$SUBCATEGORY_DATA_IMAGE_URL = "images/subcategorydata/";

$SLIDER_DATA_IMAGE_PATH = $_SERVER['DOCUMENT_ROOT']."/fantasticservices/images/sliderdata/";
$SLIDER_DATA_IMAGE_URL = "images/sliderdata/";


