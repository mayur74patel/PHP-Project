<?php 
global $appname;
$appname = "Fantastic Services";

include '../config/connection.php';
include '../config/constant.php';
require 'commonfunctions.php';
global $conn;

?>